package com.example.game.model

enum class BallGroup(val displayName: String) {
    SOLID("Bi Trơn (1-7)"),
    STRIPE("Bi Sọc (9-15)"),
    EIGHT("Bi số 8");

    val otherGroup: BallGroup?
        get() = when (this) {
            SOLID -> STRIPE
            STRIPE -> SOLID
            EIGHT -> null
        }
}

enum class PlayerId {
    PLAYER_1,
    PLAYER_2;

    val opponent: PlayerId
        get() = if (this == PLAYER_1) PLAYER_2 else PLAYER_1
}

enum class GameMode(val title: String, val subtitle: String) {
    PASS_AND_PLAY("2 Người chơi", "Chơi đối kháng trên cùng thiết bị"),
    VS_AI("Đấu với Máy", "Thử sức với AI thông minh"),
    P2P_LAN("Phòng đấu P2P", "Kết nối 2 máy qua mạng WiFi/P2P"),
    PRACTICE("Luyện tập", "Tự do ngắm bắn và thử các góc bi")
}

enum class AiDifficulty(val label: String, val description: String) {
    EASY("Dễ", "Độ chính xác vừa phải, giải trí"),
    MEDIUM("Trung bình", "Tính toán góc tốt, lực vừa đủ"),
    HARD("Cao thủ", "Ngắm chuẩn xác, điều bi điêu luyện")
}

data class PlayerInfo(
    val id: PlayerId,
    val name: String,
    val group: BallGroup? = null,
    val isAi: Boolean = false,
    val score: Int = 0
)

data class ChatMessage(
    val senderName: String,
    val text: String,
    val isMine: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class ShotContext(
    val shooter: PlayerId,
    val shooterGroupAtStart: BallGroup?,
    val shooterClearedAtStart: Boolean,
    val groupsOpenAtStart: Boolean,
    val isBreak: Boolean,
    var firstContactBallNum: Int? = null,
    var cushionAfterContact: Boolean = false,
    val railsTouched: MutableSet<Int> = mutableSetOf(),
    val pocketedBalls: MutableList<Int> = mutableListOf(),
    var scratch: Boolean = false,
    var eightBallPocketed: Boolean = false
)

enum class ShotEvent {
    CUE_HIT,
    BALL_COLLISION,
    CUSHION_COLLISION,
    POCKET_DROP,
    FOUL,
    WIN,
    LOSE
}
