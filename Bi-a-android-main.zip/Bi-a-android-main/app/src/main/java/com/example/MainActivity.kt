package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.AppScreen
import com.example.game.GameViewModel
import com.example.game.model.GameMode
import com.example.game.model.PlayerId
import com.example.game.net.P2PConnectionState
import com.example.game.ui.BilliardTableCanvas
import com.example.game.ui.CameraPiPOverlay
import com.example.game.ui.ChatDialog
import com.example.game.ui.DanmakuOverlay
import com.example.game.ui.GameHud
import com.example.game.ui.GameOverDialog
import com.example.game.ui.MainMenuScreen
import com.example.game.ui.VoiceIndicatorOverlay
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val gameViewModel: GameViewModel = viewModel()
                BilliardsGameApp(viewModel = gameViewModel)
            }
        }
    }
}

@Composable
fun BilliardsGameApp(viewModel: GameViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val p2pState by viewModel.p2pState.collectAsStateWithLifecycle()

    when (currentScreen) {
        AppScreen.MAIN_MENU -> {
            MainMenuScreen(
                soundEnabled = viewModel.soundManager.isSoundEnabled,
                hapticsEnabled = viewModel.soundManager.isHapticsEnabled,
                onToggleSound = { viewModel.toggleSound() },
                onToggleHaptics = { viewModel.toggleHaptics() },
                onStartPassAndPlay = { p1, p2 -> viewModel.startPassAndPlay(p1, p2) },
                onStartVsAi = { p1, diff -> viewModel.startVsAi(p1, diff) },
                onStartPractice = { viewModel.startPractice() },
                onHostP2PRoom = { name -> viewModel.hostP2PRoom(name) },
                onJoinP2PRoom = { code, name -> viewModel.joinP2PRoom(code, name) },
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            )
        }
        AppScreen.P2P_LOBBY -> {
            P2PLobbyScreen(
                p2pState = p2pState,
                onCancel = { viewModel.cancelP2PLobby() },
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            )
        }
        AppScreen.IN_GAME -> {
            InGameScreen(
                viewModel = viewModel,
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            )
        }
    }
}

@Composable
fun InGameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val balls by viewModel.balls.collectAsStateWithLifecycle()
    val player1 by viewModel.player1.collectAsStateWithLifecycle()
    val player2 by viewModel.player2.collectAsStateWithLifecycle()
    val currentTurn by viewModel.currentTurn.collectAsStateWithLifecycle()
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()
    val hasBallInHand by viewModel.hasBallInHand.collectAsStateWithLifecycle()
    val isBreakShot by viewModel.isBreakShot.collectAsStateWithLifecycle()
    val isGameOver by viewModel.isGameOver.collectAsStateWithLifecycle()
    val winner by viewModel.winner.collectAsStateWithLifecycle()
    val gameOverReason by viewModel.gameOverReason.collectAsStateWithLifecycle()
    val aimAngleRad by viewModel.aimAngleRad.collectAsStateWithLifecycle()
    val shotPower by viewModel.shotPower.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val recentLog by viewModel.recentLog.collectAsStateWithLifecycle()
    val danmakuItems by viewModel.danmakuItems.collectAsStateWithLifecycle()
    val isMicEnabled by viewModel.isMicEnabled.collectAsStateWithLifecycle()
    val isCameraEnabled by viewModel.isCameraEnabled.collectAsStateWithLifecycle()
    val gameMode by viewModel.gameMode.collectAsStateWithLifecycle()

    var showChatDialog by remember { mutableStateOf(false) }
    var showLeaveConfirmDialog by remember { mutableStateOf(false) }

    val isAiTurn = gameMode == GameMode.VS_AI && currentTurn == PlayerId.PLAYER_2
    val canAim = !isSimulating && !isGameOver && !isAiTurn

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF08140E))
    ) {
        // Landscape layout: HUD as a fixed-width sidebar on the left,
        // billiard table filling the rest of the (much wider than tall)
        // screen. The game is locked to landscape orientation, so the
        // table always gets the maximum width/height it can.
        Row(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. Sidebar HUD
            GameHud(
                player1 = player1,
                player2 = player2,
                currentTurn = currentTurn,
                balls = balls,
                hasBallInHand = hasBallInHand,
                isBreakShot = isBreakShot,
                isAiTurn = isAiTurn,
                canAim = canAim,
                aimAngleRad = aimAngleRad,
                shotPower = shotPower,
                soundEnabled = viewModel.soundManager.isSoundEnabled,
                recentLog = recentLog,
                isMicEnabled = isMicEnabled,
                isCameraEnabled = isCameraEnabled,
                onAngleChange = { newAngle -> viewModel.setAim(newAngle, shotPower) },
                onPowerChange = { newPower -> viewModel.setAim(aimAngleRad, newPower) },
                onShootClick = { viewModel.executeShot() },
                onToggleSound = { viewModel.toggleSound() },
                onToggleMic = { viewModel.toggleMic() },
                onToggleCamera = { viewModel.toggleCamera() },
                onConfirmBallInHand = { viewModel.confirmBallInHand() },
                onQuickChat = { text -> viewModel.sendChatMessage(text) },
                onOpenChat = { showChatDialog = true },
                onLeaveClick = { showLeaveConfirmDialog = true },
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.3f)
            )

            // 2. Billiard Table Canvas + Danmaku Overlay
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                BilliardTableCanvas(
                    balls = balls,
                    aimAngleRad = aimAngleRad,
                    shotPower = shotPower,
                    isAiming = !isSimulating && canAim,
                    canAim = canAim,
                    hasBallInHand = hasBallInHand,
                    isBreakShot = isBreakShot,
                    onAimChange = { a, p -> viewModel.setAim(a, p) },
                    onShoot = { _, _ -> viewModel.executeShot() },
                    onBallInHandMove = { x, y -> viewModel.moveBallInHand(x, y) }
                )

                // Danmaku Floating Scrolling Text Overlay directly across the pool table!
                DanmakuOverlay(
                    items = danmakuItems,
                    onItemFinished = { id -> viewModel.removeDanmaku(id) },
                    modifier = Modifier.fillMaxSize()
                )

                // Voice chat status badge — kept inside the table area (instead of the
                // full-screen top-left corner) so it never overlaps the sidebar HUD
                // now that the HUD lives on the left in landscape mode.
                VoiceIndicatorOverlay(
                    isMicActive = isMicEnabled,
                    playerName = if (currentTurn == PlayerId.PLAYER_1) player1.name else player2.name,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(start = 8.dp, top = 8.dp)
                )
            }
        }

        // Live Camera Preview PiP (draggable floating window)
        CameraPiPOverlay(
            isCameraEnabled = isCameraEnabled,
            isMicEnabled = isMicEnabled,
            playerName = player1.name,
            opponentName = player2.name,
            onCloseCamera = { viewModel.toggleCamera() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 64.dp)
        )

        // Chat Dialog
        if (showChatDialog) {
            ChatDialog(
                messages = chatMessages,
                onSendMessage = { text -> viewModel.sendChatMessage(text) },
                onDismiss = { showChatDialog = false }
            )
        }

        // Leave Match Confirm Dialog
        if (showLeaveConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showLeaveConfirmDialog = false },
                title = { Text("Rời ván đấu?", color = Color.White) },
                text = { Text("Tiến trình ván đấu hiện tại sẽ bị hủy.", color = Color.LightGray) },
                confirmButton = {
                    Button(
                        onClick = {
                            showLeaveConfirmDialog = false
                            viewModel.returnToMainMenu()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("RỜI PHÒNG")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showLeaveConfirmDialog = false }) {
                        Text("Ở LẠI", color = Color.White)
                    }
                },
                containerColor = Color(0xFF0F1E17)
            )
        }

        // Game Over Dialog
        if (isGameOver) {
            val winnerName = if (winner == PlayerId.PLAYER_1) player1.name else player2.name
            val isLocalWinner = winner == PlayerId.PLAYER_1
            GameOverDialog(
                winnerId = winner,
                winnerName = winnerName,
                resultDescription = gameOverReason,
                isLocalPlayerWinner = isLocalWinner,
                onRematchClick = { viewModel.startNewMatch() },
                onMainMenuClick = { viewModel.returnToMainMenu() }
            )
        }
    }
}

@Composable
fun P2PLobbyScreen(
    p2pState: P2PConnectionState,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0F2A1E), Color(0xFF08150E)),
                    radius = 1000f
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E17)),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (p2pState) {
                    is P2PConnectionState.Hosting -> {
                        Text(
                            text = "PHÒNG CỦA BẠN ĐÃ SẴN SÀNG",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color(0xFFFBBF24)
                        )
                        Text(
                            text = "Đọc mã 3 số này cho bạn bè trên cùng mạng WiFi:",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )

                        // Big Room Code Badge
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .background(Color(0xFF1B3828), RoundedCornerShape(12.dp))
                                .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                .padding(horizontal = 24.dp, vertical = 12.dp)
                        ) {
                            Text(
                                text = p2pState.roomCode,
                                fontWeight = FontWeight.Black,
                                fontSize = 32.sp,
                                letterSpacing = 6.sp,
                                color = Color.White
                            )

                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Mã phòng", p2pState.roomCode))
                                    Toast.makeText(context, "Đã sao chép mã phòng!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Sao chép", tint = Color(0xFF34D399))
                            }
                        }

                        Text(
                            text = "Địa chỉ IP máy chủ: ${p2pState.localIp}",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )

                        CircularProgressIndicator(
                            color = Color(0xFF10B981),
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "Đang chờ đối thủ kết nối...",
                            fontSize = 12.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                    is P2PConnectionState.Connecting -> {
                        Text(
                            text = "ĐANG KẾT NỐI...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = Color(0xFF38BDF8)
                        )
                        CircularProgressIndicator(
                            color = Color(0xFF38BDF8),
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "Đang kết nối tới mã phòng: ${p2pState.roomCode}",
                            fontSize = 12.sp,
                            color = Color.White
                        )
                    }
                    is P2PConnectionState.Error -> {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = p2pState.message,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                    else -> {}
                }

                OutlinedButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("HỦY BỎ", color = Color.White)
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme { Greeting("Android") }
}

