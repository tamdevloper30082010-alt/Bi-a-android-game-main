package com.example.game.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.sqrt

data class Ball(
    val num: Int,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var isPotted: Boolean = false,
    var pottedAnimAlpha: Float = 1f
) {
    val isCueBall: Boolean get() = num == 0
    val isEightBall: Boolean get() = num == 8
    val isStripe: Boolean get() = num in 9..15
    val isSolid: Boolean get() = num in 1..7

    val group: BallGroup?
        get() = when {
            num in 1..7 -> BallGroup.SOLID
            num in 9..15 -> BallGroup.STRIPE
            num == 8 -> BallGroup.EIGHT
            else -> null
        }

    val speed: Float get() = sqrt(vx * vx + vy * vy)

    val position: Offset get() = Offset(x, y)

    val baseColor: Color
        get() = when (num) {
            0 -> Color(0xFFF8FAFC) // Cue ball ivory white
            1, 9 -> Color(0xFFFBBF24) // Yellow
            2, 10 -> Color(0xFF2563EB) // Blue
            3, 11 -> Color(0xFFDC2626) // Red
            4, 12 -> Color(0xFF7C3AED) // Purple
            5, 13 -> Color(0xFFEA580C) // Orange
            6, 14 -> Color(0xFF16A34A) // Green
            7, 15 -> Color(0xFF881337) // Maroon / Burgundy
            8 -> Color(0xFF111827)    // 8-Ball Black
            else -> Color.White
        }

    fun copyBall(): Ball = Ball(
        num = num,
        x = x,
        y = y,
        vx = vx,
        vy = vy,
        isPotted = isPotted,
        pottedAnimAlpha = pottedAnimAlpha
    )
}
