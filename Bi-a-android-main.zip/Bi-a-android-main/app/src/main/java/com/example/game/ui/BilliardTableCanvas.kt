package com.example.game.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import com.example.game.model.Ball
import com.example.game.model.PoolTableConfig
import com.example.game.physics.AimPredictor
import com.example.game.physics.PoolPhysicsEngine
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun BilliardTableCanvas(
    balls: List<Ball>,
    aimAngleRad: Float,
    shotPower: Float,
    isAiming: Boolean,
    canAim: Boolean,
    hasBallInHand: Boolean,
    isBreakShot: Boolean,
    onAimChange: (Float, Float) -> Unit,
    onShoot: (Float, Float) -> Unit,
    onBallInHandMove: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val textPaint = remember {
        Paint().apply {
            color = android.graphics.Color.BLACK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
    }

    val cueBall = balls.find { it.isCueBall }

    val currentBalls by rememberUpdatedState(balls)
    val currentCanAim by rememberUpdatedState(canAim)
    val currentHasBallInHand by rememberUpdatedState(hasBallInHand)
    val currentIsBreakShot by rememberUpdatedState(isBreakShot)
    val currentShotPower by rememberUpdatedState(shotPower)
    val currentAimAngleRad by rememberUpdatedState(aimAngleRad)

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val scale = min(size.width / PoolTableConfig.WIDTH, size.height / PoolTableConfig.HEIGHT)
                    val ox = (size.width - PoolTableConfig.WIDTH * scale) / 2f
                    val oy = (size.height - PoolTableConfig.HEIGHT * scale) / 2f

                    val startX = (down.position.x - ox) / scale
                    val startY = (down.position.y - oy) / scale

                    if (currentHasBallInHand) {
                        if (PoolPhysicsEngine.isValidCuePlacement(startX, startY, currentBalls, currentIsBreakShot)) {
                            onBallInHandMove(startX, startY)
                        }
                        var pointerId = down.id
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.find { it.id == pointerId } ?: break
                            if (!change.pressed) break
                            change.consume()
                            val curX = (change.position.x - ox) / scale
                            val curY = (change.position.y - oy) / scale
                            if (PoolPhysicsEngine.isValidCuePlacement(curX, curY, currentBalls, currentIsBreakShot)) {
                                onBallInHandMove(curX, curY)
                            }
                        }
                    } else if (currentCanAim) {
                        val cue = currentBalls.find { it.isCueBall }
                        if (cue != null && !cue.isPotted) {
                            var angle = currentAimAngleRad
                            var power = currentShotPower
                            var hasDragged = false
                            var isPullingCue = false
                            val pointerId = down.id

                            val dx = startX - cue.x
                            val dy = startY - cue.y
                            val dist = sqrt(dx * dx + dy * dy)

                            // Tapping anywhere adjusts aim angle towards that point
                            if (dist > 15f) {
                                angle = (atan2(dy, dx) + 2f * PI.toFloat()) % (2f * PI.toFloat())
                                onAimChange(angle, power)
                            }

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.find { it.id == pointerId } ?: break
                                if (!change.pressed) {
                                    // Released finger: if player pulled back the cue with good power, execute shot!
                                    if (isPullingCue && power >= 0.18f) {
                                        onShoot(angle, power)
                                    }
                                    break
                                }
                                change.consume()
                                val curX = (change.position.x - ox) / scale
                                val curY = (change.position.y - oy) / scale
                                val moveDx = curX - cue.x
                                val moveDy = curY - cue.y
                                val currentDist = sqrt(moveDx * moveDx + moveDy * moveDy)

                                if (currentDist > 10f) {
                                    hasDragged = true
                                    val touchAngle = (atan2(moveDy, moveDx) + 2f * PI.toFloat()) % (2f * PI.toFloat())
                                    val diff = abs(touchAngle - angle)
                                    val normalizedDiff = if (diff > PI.toFloat()) 2f * PI.toFloat() - diff else diff

                                    // If dragging in the opposite direction of the shot (> 90 degrees away), pull back cue to charge power
                                    if (normalizedDiff > (PI.toFloat() * 0.55f)) {
                                        isPullingCue = true
                                        power = (currentDist / PoolTableConfig.MAX_DRAG_DISTANCE).coerceIn(0.12f, 1f)
                                    } else {
                                        // Otherwise rotate aim direction
                                        isPullingCue = false
                                        angle = touchAngle
                                    }
                                    onAimChange(angle, power)
                                }
                            }
                        }
                    }
                }
            }
    ) {
        val scale = min(size.width / PoolTableConfig.WIDTH, size.height / PoolTableConfig.HEIGHT)
        val ox = (size.width - PoolTableConfig.WIDTH * scale) / 2f
        val oy = (size.height - PoolTableConfig.HEIGHT * scale) / 2f

        drawIntoCanvas { canvas ->
            canvas.nativeCanvas.save()
            canvas.nativeCanvas.translate(ox, oy)
            canvas.nativeCanvas.scale(scale, scale)

            // 1. Draw Wood Outer Frame & Rails
            drawTableWoodFrame()

            // 2. Draw Emerald Felt Cloth
            drawTableFelt()

            // 3. Draw Sights / Diamond Markers
            drawDiamondSights()

            // 4. Draw Table Markings (Head string & spots)
            drawTableMarkings()

            // 5. Draw 6 Pockets
            drawPockets()

            // 6. Draw Billiard Balls
            drawBalls(balls, textPaint)

            // 7. Draw Aiming Guideline & Cue Stick
            if (canAim && cueBall != null && !cueBall.isPotted && !hasBallInHand) {
                drawAimGuideAndCue(cueBall, aimAngleRad, shotPower, balls)
            }

            // 8. Ball-in-hand placement indicator
            if (hasBallInHand && cueBall != null) {
                drawBallInHandOverlay(cueBall, balls, isBreakShot)
            }

            canvas.nativeCanvas.restore()
        }
    }
}

private fun DrawScope.drawTableWoodFrame() {
    val w = PoolTableConfig.WIDTH
    val h = PoolTableConfig.HEIGHT
    val r = 24f

    // Outer Rich Mahogany Wood Border
    drawRoundRect(
        brush = Brush.linearGradient(
            colors = listOf(
                Color(0xFF5D2E14),
                Color(0xFF381A0B),
                Color(0xFF241006)
            ),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        ),
        size = Size(w, h),
        cornerRadius = CornerRadius(r, r)
    )

    // Wood Grain Inner Shadow / Bevel
    drawRoundRect(
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFF7A3E1B), Color(0xFF2A1307)),
            start = Offset(6f, 6f),
            end = Offset(w - 6f, h - 6f)
        ),
        topLeft = Offset(4f, 4f),
        size = Size(w - 8f, h - 8f),
        cornerRadius = CornerRadius(r - 2f, r - 2f)
    )

    // Inner Dark Cushion Rim
    drawRoundRect(
        color = Color(0xFF1E0E05),
        topLeft = Offset(PoolTableConfig.RAIL_WIDTH - 6f, PoolTableConfig.RAIL_WIDTH - 6f),
        size = Size(
            w - (PoolTableConfig.RAIL_WIDTH - 6f) * 2f,
            h - (PoolTableConfig.RAIL_WIDTH - 6f) * 2f
        ),
        cornerRadius = CornerRadius(6f, 6f)
    )
}

private fun DrawScope.drawTableFelt() {
    val left = PoolTableConfig.PLAY_LEFT
    val top = PoolTableConfig.PLAY_TOP
    val width = PoolTableConfig.PLAY_RIGHT - left
    val height = PoolTableConfig.PLAY_BOTTOM - top

    // Deep Emerald Tournament Felt with ambient center glow
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                Color(0xFF127A45),
                Color(0xFF0D6337),
                Color(0xFF074726)
            ),
            center = Offset(PoolTableConfig.WIDTH * 0.5f, PoolTableConfig.HEIGHT * 0.5f),
            radius = PoolTableConfig.WIDTH * 0.65f
        ),
        topLeft = Offset(left, top),
        size = Size(width, height)
    )

    // Subtle inner cushion shadow for 3D depth
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(Color(0x77000000), Color.Transparent),
            start = Offset(left, top),
            end = Offset(left, top + 14f)
        ),
        topLeft = Offset(left, top),
        size = Size(width, 14f)
    )
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color(0x77000000)),
            start = Offset(left, PoolTableConfig.PLAY_BOTTOM - 14f),
            end = Offset(left, PoolTableConfig.PLAY_BOTTOM)
        ),
        topLeft = Offset(left, PoolTableConfig.PLAY_BOTTOM - 14f),
        size = Size(width, 14f)
    )
}

private fun DrawScope.drawDiamondSights() {
    val rw = PoolTableConfig.RAIL_WIDTH * 0.5f
    val diamondColor = Color(0xFFFDE68A) // Pearlescent ivory gold

    // Diamonds along top and bottom rails (6 each)
    val xPositions = listOf(0.18f, 0.32f, 0.44f, 0.56f, 0.68f, 0.82f)
    for (frac in xPositions) {
        val px = PoolTableConfig.WIDTH * frac
        drawCircle(diamondColor, radius = 2.4f, center = Offset(px, rw))
        drawCircle(diamondColor, radius = 2.4f, center = Offset(px, PoolTableConfig.HEIGHT - rw))
    }

    // Diamonds along left and right rails (3 each)
    val yPositions = listOf(0.28f, 0.5f, 0.72f)
    for (frac in yPositions) {
        val py = PoolTableConfig.HEIGHT * frac
        drawCircle(diamondColor, radius = 2.4f, center = Offset(rw, py))
        drawCircle(diamondColor, radius = 2.4f, center = Offset(PoolTableConfig.WIDTH - rw, py))
    }
}

private fun DrawScope.drawTableMarkings() {
    // Head string line
    val headX = PoolTableConfig.HEAD_SPOT.x
    drawLine(
        color = Color(0x33FFFFFF),
        start = Offset(headX, PoolTableConfig.PLAY_TOP),
        end = Offset(headX, PoolTableConfig.PLAY_BOTTOM),
        strokeWidth = 1f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
    )

    // Head spot
    drawCircle(
        color = Color(0x55FFFFFF),
        radius = 3.5f,
        center = PoolTableConfig.HEAD_SPOT
    )
    drawCircle(
        color = Color(0xAAFFFFFF),
        radius = 1.5f,
        center = PoolTableConfig.HEAD_SPOT
    )

    // Foot spot
    drawCircle(
        color = Color(0x55FFFFFF),
        radius = 3.5f,
        center = PoolTableConfig.FOOT_SPOT
    )
    drawCircle(
        color = Color(0xAAFFFFFF),
        radius = 1.5f,
        center = PoolTableConfig.FOOT_SPOT
    )
}

private fun DrawScope.drawPockets() {
    for (p in PoolTableConfig.POCKETS) {
        // Outer metallic rim
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF4A3420), Color(0xFF1F1207)),
                center = p,
                radius = PoolTableConfig.POCKET_RADIUS + 4f
            ),
            radius = PoolTableConfig.POCKET_RADIUS + 3f,
            center = p
        )

        // Pocket hole inner black void
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF030504), Color(0xFF0E1310), Color(0xFF1A221C)),
                center = Offset(p.x + 2f, p.y + 2f),
                radius = PoolTableConfig.POCKET_RADIUS
            ),
            radius = PoolTableConfig.POCKET_RADIUS,
            center = p
        )
    }
}

private fun DrawScope.drawBalls(balls: List<Ball>, textPaint: Paint) {
    for (b in balls) {
        if (b.isPotted) continue
        drawSingleBall(b, textPaint)
    }
}

private fun DrawScope.drawSingleBall(b: Ball, textPaint: Paint) {
    val r = PoolTableConfig.BALL_RADIUS
    val cx = b.x
    val cy = b.y

    // 1. Soft drop shadow on felt
    drawOval(
        color = Color(0x66000000),
        topLeft = Offset(cx - r * 0.9f + 2f, cy - r * 0.45f + 3.5f),
        size = Size(r * 1.8f, r * 1.0f)
    )

    if (b.isCueBall) {
        // Cue ball: Ivory white with spherical 3D shading
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF1F5F9),
                    Color(0xFFCBD5E1),
                    Color(0xFF94A3B8)
                ),
                center = Offset(cx - r * 0.35f, cy - r * 0.35f),
                radius = r * 1.15f
            ),
            radius = r,
            center = Offset(cx, cy)
        )

        // Subtle red aiming dot on cue ball
        drawCircle(
            color = Color(0xAAEF4444),
            radius = 1.5f,
            center = Offset(cx, cy)
        )
    } else {
        // Numbered Object Ball
        val baseColor = b.baseColor

        if (b.isStripe) {
            // Stripe ball: White base with colored horizontal band
            drawCircle(
                color = Color(0xFFF8FAFC),
                radius = r,
                center = Offset(cx, cy)
            )

            val clipPath = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(cx - r, cy - r, cx + r, cy + r))
            }
            clipPath(clipPath) {
                drawRect(
                    color = baseColor,
                    topLeft = Offset(cx - r, cy - r * 0.52f),
                    size = Size(r * 2f, r * 1.04f)
                )
            }
        } else {
            // Solid ball: Full color
            drawCircle(
                color = baseColor,
                radius = r,
                center = Offset(cx, cy)
            )
        }

        // Center white circle for number
        val circleR = r * 0.52f
        drawCircle(
            color = Color(0xFFF8FAFC),
            radius = circleR,
            center = Offset(cx, cy)
        )

        // Draw number
        drawIntoCanvas { canvas ->
            textPaint.textSize = r * 0.72f
            textPaint.color = if (b.num == 8) android.graphics.Color.BLACK else android.graphics.Color.DKGRAY
            canvas.nativeCanvas.drawText(
                b.num.toString(),
                cx,
                cy + (textPaint.textSize * 0.36f),
                textPaint
            )
        }

        // 3D Spherical Glaze Highlight on top
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0x66FFFFFF),
                    Color.Transparent,
                    Color(0x55000000)
                ),
                center = Offset(cx - r * 0.35f, cy - r * 0.35f),
                radius = r * 1.15f
            ),
            radius = r,
            center = Offset(cx, cy)
        )
    }

    // Crisp specular light pinpoint
    drawCircle(
        color = Color(0xAAFFFFFF),
        radius = r * 0.22f,
        center = Offset(cx - r * 0.32f, cy - r * 0.32f)
    )
}

private fun DrawScope.drawAimGuideAndCue(
    cueBall: Ball,
    aimAngleRad: Float,
    shotPower: Float,
    balls: List<Ball>
) {
    val prediction = AimPredictor.calculateAim(cueBall, aimAngleRad, balls)
    val r = PoolTableConfig.BALL_RADIUS

    // 1. Dotted laser guideline to target/ghost ball
    drawLine(
        color = Color(0xCCF8FAFC),
        start = prediction.cueBallOrigin,
        end = prediction.guidelineEnd,
        strokeWidth = 2f,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
    )

    // 2. Ghost Ball preview
    if (prediction.ghostBallCenter != null) {
        drawCircle(
            color = Color(0x44F8FAFC),
            radius = r,
            center = prediction.ghostBallCenter
        )
        drawCircle(
            color = Color(0xAA34D399),
            radius = r,
            center = prediction.ghostBallCenter,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f)
        )

        // 3. Deflection path of target ball towards pocket
        if (prediction.targetDeflectionEnd != null && prediction.targetBall != null) {
            drawLine(
                color = Color(0xFFFBBF24),
                start = prediction.targetBall.position,
                end = prediction.targetDeflectionEnd,
                strokeWidth = 2.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 4f), 0f)
            )
            drawCircle(
                color = Color(0xFFFBBF24),
                radius = 3.5f,
                center = prediction.targetDeflectionEnd
            )
        }
    }

    // 4. Wooden Cue Stick
    val cueLength = 280f
    val pullBack = 16f + shotPower * 90f // Pulled back with shot power
    val cueDirX = cos(aimAngleRad)
    val cueDirY = sin(aimAngleRad)

    // Cue stick tip start and butt end
    val tipX = cueBall.x - cueDirX * (r + pullBack)
    val tipY = cueBall.y - cueDirY * (r + pullBack)

    val buttX = tipX - cueDirX * cueLength
    val buttY = tipY - cueDirY * cueLength

    // Ferrule and Chalk Tip
    drawLine(
        color = Color(0xFF38BDF8), // Blue chalk tip
        start = Offset(tipX, tipY),
        end = Offset(tipX - cueDirX * 5f, tipY - cueDirY * 5f),
        strokeWidth = 5f
    )
    drawLine(
        color = Color(0xFFF1F5F9), // White ferrule
        start = Offset(tipX - cueDirX * 5f, tipY - cueDirY * 5f),
        end = Offset(tipX - cueDirX * 12f, tipY - cueDirY * 12f),
        strokeWidth = 6f
    )

    // Maple wood shaft
    drawLine(
        brush = Brush.linearGradient(
            colors = listOf(Color(0xFFE2C498), Color(0xFFC79E67), Color(0xFF8C5C2E)),
            start = Offset(tipX, tipY),
            end = Offset(buttX, buttY)
        ),
        start = Offset(tipX - cueDirX * 12f, tipY - cueDirY * 12f),
        end = Offset(buttX + cueDirX * 80f, buttY + cueDirY * 80f),
        strokeWidth = 7.5f
    )

    // Grip & Butt
    drawLine(
        color = Color(0xFF1E293B), // Dark leather grip
        start = Offset(buttX + cueDirX * 80f, buttY + cueDirY * 80f),
        end = Offset(buttX, buttY),
        strokeWidth = 9.5f
    )
}

private fun DrawScope.drawBallInHandOverlay(
    cueBall: Ball,
    balls: List<Ball>,
    isBreakShot: Boolean
) {
    val r = PoolTableConfig.BALL_RADIUS
    val isValid = PoolPhysicsEngine.isValidCuePlacement(cueBall.x, cueBall.y, balls, isBreakShot)

    val haloColor = if (isValid) Color(0x8810B981) else Color(0x88EF4444)
    val ringColor = if (isValid) Color(0xFF10B981) else Color(0xFFEF4444)

    drawCircle(
        color = haloColor,
        radius = r * 2.2f,
        center = Offset(cueBall.x, cueBall.y)
    )
    drawCircle(
        color = ringColor,
        radius = r * 2.2f,
        center = Offset(cueBall.x, cueBall.y),
        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f)
    )
}
