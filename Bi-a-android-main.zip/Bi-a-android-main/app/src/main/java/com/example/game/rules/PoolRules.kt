package com.example.game.rules

import com.example.game.model.Ball
import com.example.game.model.BallGroup
import com.example.game.model.PlayerId
import com.example.game.model.PlayerInfo
import com.example.game.model.ShotContext
import com.example.game.model.ShotEvent

data class ShotEvaluation(
    val isFoul: Boolean,
    val foulReasons: List<String>,
    val nextTurn: PlayerId,
    val ballInHandFor: PlayerId?,
    val isGameOver: Boolean,
    val winner: PlayerId?,
    val groupAssignmentP1: BallGroup?,
    val groupAssignmentP2: BallGroup?,
    val events: List<ShotEvent>,
    val logMessage: String
)

object PoolRules {

    fun evaluateShot(
        shotCtx: ShotContext,
        balls: List<Ball>,
        players: Map<PlayerId, PlayerInfo>
    ): ShotEvaluation {
        val shooter = shotCtx.shooter
        val opponent = shooter.opponent
        val shooterPlayer = players[shooter] ?: PlayerInfo(shooter, "Người chơi")
        val opponentPlayer = players[opponent] ?: PlayerInfo(opponent, "Đối thủ")

        val foulReasons = mutableListOf<String>()
        val events = mutableListOf<ShotEvent>()

        var isFoul = false

        // 1. Check Scratch (Cue ball in pocket)
        if (shotCtx.scratch) {
            isFoul = true
            foulReasons.add("Bi cái rơi vào lỗ (Scratch)")
        }

        // 2. Check First Contact
        val firstContact = shotCtx.firstContactBallNum
        if (firstContact == null) {
            isFoul = true
            foulReasons.add("Không chạm vào bất kỳ bi nào")
        } else if (!shotCtx.groupsOpenAtStart) {
            // Check if contacted correct group
            val requiredGroup = if (shotCtx.shooterClearedAtStart) {
                BallGroup.EIGHT
            } else {
                shotCtx.shooterGroupAtStart
            }

            val contactGroup = when (firstContact) {
                in 1..7 -> BallGroup.SOLID
                in 9..15 -> BallGroup.STRIPE
                8 -> BallGroup.EIGHT
                else -> null
            }

            if (contactGroup != requiredGroup) {
                isFoul = true
                val neededDesc = if (requiredGroup == BallGroup.EIGHT) "bi số 8" else requiredGroup?.displayName
                foulReasons.add("Chạm sai nhóm bi (phải chạm $neededDesc trước)")
            }
        }

        // 3. Rail or Pocket check after contact
        if (!isFoul && shotCtx.pocketedBalls.isEmpty() && !shotCtx.eightBallPocketed) {
            if (shotCtx.isBreak) {
                if (shotCtx.railsTouched.size < 4) {
                    isFoul = true
                    foulReasons.add("Giao bóng không hợp lệ (cần ít nhất 4 bi chạm băng)")
                }
            } else if (!shotCtx.cushionAfterContact) {
                isFoul = true
                foulReasons.add("Không có bi nào chạm băng sau va chạm")
            }
        }

        // Add sound events
        if (shotCtx.pocketedBalls.isNotEmpty() || shotCtx.eightBallPocketed) {
            events.add(ShotEvent.POCKET_DROP)
        }
        if (isFoul) {
            events.add(ShotEvent.FOUL)
        }

        // 4. Group Assignment if still open
        var newP1Group = players[PlayerId.PLAYER_1]?.group
        var newP2Group = players[PlayerId.PLAYER_2]?.group

        if (shotCtx.groupsOpenAtStart && shotCtx.pocketedBalls.isNotEmpty() && !isFoul) {
            val solidsPotted = shotCtx.pocketedBalls.count { it in 1..7 }
            val stripesPotted = shotCtx.pocketedBalls.count { it in 9..15 }

            if (solidsPotted > 0 && stripesPotted == 0) {
                if (shooter == PlayerId.PLAYER_1) {
                    newP1Group = BallGroup.SOLID
                    newP2Group = BallGroup.STRIPE
                } else {
                    newP2Group = BallGroup.SOLID
                    newP1Group = BallGroup.STRIPE
                }
            } else if (stripesPotted > 0 && solidsPotted == 0) {
                if (shooter == PlayerId.PLAYER_1) {
                    newP1Group = BallGroup.STRIPE
                    newP2Group = BallGroup.SOLID
                } else {
                    newP2Group = BallGroup.STRIPE
                    newP1Group = BallGroup.SOLID
                }
            }
        }

        // 5. Check 8-Ball Win / Loss Condition
        if (shotCtx.eightBallPocketed) {
            val shooterGroup = players[shooter]?.group ?: (if (shooter == PlayerId.PLAYER_1) newP1Group else newP2Group)
            val shooterHasRemaining = balls.any { !it.isPotted && it.num != 0 && it.num != 8 && it.group == shooterGroup }

            return if (shooterGroup != null && !shooterHasRemaining && !isFoul) {
                // Legitimate Win!
                events.add(ShotEvent.WIN)
                ShotEvaluation(
                    isFoul = false,
                    foulReasons = emptyList(),
                    nextTurn = shooter,
                    ballInHandFor = null,
                    isGameOver = true,
                    winner = shooter,
                    groupAssignmentP1 = newP1Group,
                    groupAssignmentP2 = newP2Group,
                    events = events,
                    logMessage = "🏆 ${shooterPlayer.name} đưa bi số 8 vào lỗ thành công — THẮNG CUỘC!"
                )
            } else {
                // Instant Loss due to premature 8-ball or foul
                val lossReason = if (isFoul) "phạm quy khi đánh bi 8" else "ăn bi số 8 khi chưa dọn sạch nhóm bi"
                events.add(ShotEvent.LOSE)
                ShotEvaluation(
                    isFoul = true,
                    foulReasons = listOf(lossReason),
                    nextTurn = opponent,
                    ballInHandFor = null,
                    isGameOver = true,
                    winner = opponent,
                    groupAssignmentP1 = newP1Group,
                    groupAssignmentP2 = newP2Group,
                    events = events,
                    logMessage = "☠️ ${shooterPlayer.name} $lossReason — THUA TRẬN! ${opponentPlayer.name} chiến thắng."
                )
            }
        }

        // 6. Normal Turn Resolution
        return if (isFoul) {
            val reasonStr = foulReasons.joinToString(", ")
            ShotEvaluation(
                isFoul = true,
                foulReasons = foulReasons,
                nextTurn = opponent,
                ballInHandFor = opponent,
                isGameOver = false,
                winner = null,
                groupAssignmentP1 = newP1Group,
                groupAssignmentP2 = newP2Group,
                events = events,
                logMessage = "⚠️ Phạm quy: $reasonStr. ${opponentPlayer.name} được đặt bi cái tự do."
            )
        } else {
            val shooterGroup = players[shooter]?.group ?: (if (shooter == PlayerId.PLAYER_1) newP1Group else newP2Group)
            val pottedOwnBall = if (shooterGroup != null) {
                shotCtx.pocketedBalls.any {
                    (shooterGroup == BallGroup.SOLID && it in 1..7) ||
                            (shooterGroup == BallGroup.STRIPE && it in 9..15)
                }
            } else {
                // Open table: any numbered ball pocketed keeps the turn
                shotCtx.pocketedBalls.isNotEmpty()
            }

            if (pottedOwnBall) {
                ShotEvaluation(
                    isFoul = false,
                    foulReasons = emptyList(),
                    nextTurn = shooter,
                    ballInHandFor = null,
                    isGameOver = false,
                    winner = null,
                    groupAssignmentP1 = newP1Group,
                    groupAssignmentP2 = newP2Group,
                    events = events,
                    logMessage = "${shooterPlayer.name} ăn bi thành công, tiếp tục lượt đánh."
                )
            } else {
                val switchMsg = if (shotCtx.pocketedBalls.isNotEmpty()) {
                    "${shooterPlayer.name} ăn bi của đối thủ, chuyển lượt."
                } else {
                    "${shooterPlayer.name} đánh trượt, chuyển lượt cho ${opponentPlayer.name}."
                }
                ShotEvaluation(
                    isFoul = false,
                    foulReasons = emptyList(),
                    nextTurn = opponent,
                    ballInHandFor = null,
                    isGameOver = false,
                    winner = null,
                    groupAssignmentP1 = newP1Group,
                    groupAssignmentP2 = newP2Group,
                    events = events,
                    logMessage = switchMsg
                )
            }
        }
    }
}
