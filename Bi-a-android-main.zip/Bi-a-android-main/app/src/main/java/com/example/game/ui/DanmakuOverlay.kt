package com.example.game.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

data class DanmakuItem(
    val id: Long,
    val senderName: String,
    val text: String,
    val isMine: Boolean,
    val lane: Int
)

@Composable
fun DanmakuOverlay(
    items: List<DanmakuItem>,
    onItemFinished: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier.fillMaxSize()
    ) {
        val screenWidthPx = constraints.maxWidth.toFloat()
        val laneHeightDp = 34.dp
        val topPaddingDp = 10.dp

        for (item in items) {
            DanmakuFloatingView(
                item = item,
                screenWidthPx = screenWidthPx,
                laneOffsetDp = topPaddingDp + (laneHeightDp * (item.lane % 5)),
                onFinished = { onItemFinished(item.id) }
            )
        }
    }
}

@Composable
private fun DanmakuFloatingView(
    item: DanmakuItem,
    screenWidthPx: Float,
    laneOffsetDp: androidx.compose.ui.unit.Dp,
    onFinished: () -> Unit
) {
    val startX = screenWidthPx + 60f
    val endX = -700f
    val animX = remember { Animatable(startX) }

    LaunchedEffect(item.id) {
        animX.animateTo(
            targetValue = endX,
            animationSpec = tween(
                durationMillis = 5200,
                easing = LinearEasing
            )
        )
        onFinished()
    }

    Box(
        modifier = Modifier
            .offset { IntOffset(animX.value.roundToInt(), 0) }
            .offset(y = laneOffsetDp)
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (item.isMine) {
                        Brush.horizontalGradient(
                            listOf(Color(0xEE064E3B), Color(0xCC047857))
                        )
                    } else {
                        Brush.horizontalGradient(
                            listOf(Color(0xEE1E1B4B), Color(0xCC312E81))
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (item.isMine) Color(0xFF34D399) else Color(0xFF818CF8),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sender Avatar dot
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (item.isMine) Color(0xFF10B981) else Color(0xFF6366F1))
            )

            Text(
                text = "  ${item.senderName}: ",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (item.isMine) Color(0xFF6EE7B7) else Color(0xFFA5B4FC)
            )

            Text(
                text = item.text,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = Color.White
            )
        }
    }
}
