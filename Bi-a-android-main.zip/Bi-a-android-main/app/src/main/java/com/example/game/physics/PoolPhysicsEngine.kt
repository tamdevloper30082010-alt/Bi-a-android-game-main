package com.example.game.physics

import com.example.game.model.Ball
import com.example.game.model.PoolTableConfig
import com.example.game.model.ShotContext
import com.example.game.model.ShotEvent
import kotlin.math.abs
import kotlin.math.sqrt

object PoolPhysicsEngine {

    fun createInitialBalls(): List<Ball> {
        val list = mutableListOf<Ball>()
        val r = PoolTableConfig.BALL_RADIUS

        // Cue ball at head spot
        list.add(
            Ball(
                num = 0,
                x = PoolTableConfig.HEAD_SPOT.x,
                y = PoolTableConfig.HEAD_SPOT.y
            )
        )

        // 15-ball standard triangle rack
        val footX = PoolTableConfig.FOOT_SPOT.x
        val midY = PoolTableConfig.FOOT_SPOT.y

        val rows = listOf(
            listOf(1),
            listOf(9, 2),
            listOf(10, 8, 3),
            listOf(4, 11, 5, 12),
            listOf(6, 13, 7, 14, 15)
        )

        val dx = r * 1.76f
        val dy = r * 2.05f

        for (rowIndex in rows.indices) {
            val rowBalls = rows[rowIndex]
            val count = rowBalls.size
            for (i in 0 until count) {
                val num = rowBalls[i]
                val bx = footX + rowIndex * dx
                val by = midY - rowIndex * (dy * 0.5f) + i * dy
                list.add(Ball(num = num, x = bx, y = by))
            }
        }

        return list
    }

    fun isAnyBallMoving(balls: List<Ball>): Boolean {
        for (b in balls) {
            if (b.isPotted) continue
            if (abs(b.vx) > PoolTableConfig.MIN_SPEED || abs(b.vy) > PoolTableConfig.MIN_SPEED) {
                return true
            }
        }
        return false
    }

    fun stepPhysics(
        balls: List<Ball>,
        shotCtx: ShotContext?,
        onEvent: (ShotEvent, Float) -> Unit = { _, _ -> }
    ) {
        val sub = PoolTableConfig.SUBSTEPS
        val r = PoolTableConfig.BALL_RADIUS
        val r2 = r * 2f
        val frictionPerSub = Math.pow(PoolTableConfig.FRICTION.toDouble(), (1.0 / sub)).toFloat()

        for (s in 0 until sub) {
            // 1. Move balls
            for (b in balls) {
                if (b.isPotted) continue
                b.x += b.vx / sub
                b.y += b.vy / sub
            }

            // 2. Check pocket entries first
            for (b in balls) {
                if (b.isPotted) continue
                for (pocket in PoolTableConfig.POCKETS) {
                    val pdx = b.x - pocket.x
                    val pdy = b.y - pocket.y
                    val dist = sqrt(pdx * pdx + pdy * pdy)
                    if (dist < PoolTableConfig.POCKET_RADIUS - 1f) {
                        b.isPotted = true
                        b.vx = 0f
                        b.vy = 0f
                        onEvent(ShotEvent.POCKET_DROP, 1f)
                        if (shotCtx != null) {
                            if (b.isCueBall) {
                                shotCtx.scratch = true
                            } else if (b.isEightBall) {
                                shotCtx.eightBallPocketed = true
                            } else {
                                shotCtx.pocketedBalls.add(b.num)
                            }
                        }
                        break
                    }
                }
            }

            // 3. Cushion bounces (with pocket gap allowances)
            for (b in balls) {
                if (b.isPotted) continue

                // Check if near any pocket mouth — if so, don't hard-bounce off the rail
                var isNearPocket = false
                for (p in PoolTableConfig.POCKETS) {
                    val pdx = b.x - p.x
                    val pdy = b.y - p.y
                    if (sqrt(pdx * pdx + pdy * pdy) < PoolTableConfig.POCKET_MOUTH_RADIUS) {
                        isNearPocket = true
                        break
                    }
                }
                if (isNearPocket) continue

                var hitCushion = false
                if (b.x - r < PoolTableConfig.PLAY_LEFT) {
                    b.x = PoolTableConfig.PLAY_LEFT + r
                    b.vx = -b.vx * PoolTableConfig.CUSHION_RESTITUTION
                    hitCushion = true
                } else if (b.x + r > PoolTableConfig.PLAY_RIGHT) {
                    b.x = PoolTableConfig.PLAY_RIGHT - r
                    b.vx = -b.vx * PoolTableConfig.CUSHION_RESTITUTION
                    hitCushion = true
                }

                if (b.y - r < PoolTableConfig.PLAY_TOP) {
                    b.y = PoolTableConfig.PLAY_TOP + r
                    b.vy = -b.vy * PoolTableConfig.CUSHION_RESTITUTION
                    hitCushion = true
                } else if (b.y + r > PoolTableConfig.PLAY_BOTTOM) {
                    b.y = PoolTableConfig.PLAY_BOTTOM - r
                    b.vy = -b.vy * PoolTableConfig.CUSHION_RESTITUTION
                    hitCushion = true
                }

                if (hitCushion) {
                    onEvent(ShotEvent.CUSHION_COLLISION, b.speed / PoolTableConfig.MAX_SHOT_SPEED)
                    if (shotCtx != null) {
                        if (shotCtx.firstContactBallNum != null) {
                            shotCtx.cushionAfterContact = true
                        }
                        if (shotCtx.isBreak) {
                            shotCtx.railsTouched.add(b.num)
                        }
                    }
                }
            }

            // 4. Ball-to-ball collisions
            val ballCount = balls.size
            for (i in 0 until ballCount) {
                val b1 = balls[i]
                if (b1.isPotted) continue

                for (j in i + 1 until ballCount) {
                    val b2 = balls[j]
                    if (b2.isPotted) continue

                    val dx = b2.x - b1.x
                    val dy = b2.y - b1.y
                    val dist = sqrt(dx * dx + dy * dy)

                    if (dist > 0f && dist < r2) {
                        // Separate overlapping balls
                        val overlap = (r2 - dist) * 0.5f
                        val nx = dx / dist
                        val ny = dy / dist

                        b1.x -= nx * overlap
                        b1.y -= ny * overlap
                        b2.x += nx * overlap
                        b2.y += ny * overlap

                        // Record first contact of cue ball
                        if (shotCtx != null && shotCtx.firstContactBallNum == null) {
                            if (b1.isCueBall && !b2.isCueBall) {
                                shotCtx.firstContactBallNum = b2.num
                            } else if (b2.isCueBall && !b1.isCueBall) {
                                shotCtx.firstContactBallNum = b1.num
                            }
                        }

                        // Relative velocity along collision normal
                        val rvx = b2.vx - b1.vx
                        val rvy = b2.vy - b1.vy
                        val velAlongNormal = rvx * nx + rvy * ny

                        // Do not resolve if velocities are separating
                        if (velAlongNormal < 0f) {
                            val impulse = -(1f + PoolTableConfig.BALL_RESTITUTION) * velAlongNormal * 0.5f
                            val ix = impulse * nx
                            val iy = impulse * ny

                            b1.vx -= ix
                            b1.vy -= iy
                            b2.vx += ix
                            b2.vy += iy

                            val collisionPower = abs(velAlongNormal) / PoolTableConfig.MAX_SHOT_SPEED
                            onEvent(ShotEvent.BALL_COLLISION, collisionPower.coerceIn(0.1f, 1f))
                        }
                    }
                }
            }

            // 5. Apply friction and speed limits EVERY substep.
            // (Bug fixed: this block used to run only once per stepPhysics() call,
            // using frictionPerSub = FRICTION^(1/sub) — which is a much weaker decay
            // than intended. That made balls barely slow down, so they kept rolling
            // at near-full speed until the simulation's hard frame cap forcibly zeroed
            // their velocity, which looked like the screen "freezing" mid-roll.
            // Applying frictionPerSub once per substep (sub times per call) restores
            // the intended total decay of FRICTION per call, so balls decelerate and
            // come to a natural, smooth stop instead of rolling for too long.)
            for (b in balls) {
                if (b.isPotted) continue
                if (b.vx.isNaN() || b.vy.isNaN()) {
                    b.vx = 0f
                    b.vy = 0f
                }

                // Multiplicative drag (felt/air resistance) + a small constant
                // rolling-friction decel, so every ball slows to a full, natural
                // stop in a bounded amount of time instead of coasting almost
                // forever (pure exponential decay never truly reaches zero).
                val spdBefore = sqrt(b.vx * b.vx + b.vy * b.vy)
                if (spdBefore > 0f) {
                    var newSpd = spdBefore * frictionPerSub - (PoolTableConfig.ROLLING_DECEL / sub)
                    if (newSpd < 0f) newSpd = 0f
                    val scale = newSpd / spdBefore
                    b.vx *= scale
                    b.vy *= scale
                }

                val spd = sqrt(b.vx * b.vx + b.vy * b.vy)
                if (spd < PoolTableConfig.MIN_SPEED * 1.3f) {
                    b.vx = 0f
                    b.vy = 0f
                } else if (spd > PoolTableConfig.MAX_SHOT_SPEED) {
                    val scale = PoolTableConfig.MAX_SHOT_SPEED / spd
                    b.vx *= scale
                    b.vy *= scale
                }
            }
        }
    }

    fun isValidCuePlacement(x: Float, y: Float, balls: List<Ball>, isBreakShot: Boolean = false): Boolean {
        val r = PoolTableConfig.BALL_RADIUS
        if (x - r < PoolTableConfig.PLAY_LEFT || x + r > PoolTableConfig.PLAY_RIGHT) return false
        if (y - r < PoolTableConfig.PLAY_TOP || y + r > PoolTableConfig.PLAY_BOTTOM) return false

        // In break shot, cue ball must be placed behind the head string line
        if (isBreakShot && x > PoolTableConfig.HEAD_SPOT.x) {
            return false
        }

        for (b in balls) {
            if (b.isPotted || b.isCueBall) continue
            val dx = b.x - x
            val dy = b.y - y
            if (sqrt(dx * dx + dy * dy) < r * 2.15f) {
                return false
            }
        }
        return true
    }
}
