package com.example.game.physics

import androidx.compose.ui.geometry.Offset
import com.example.game.model.Ball
import com.example.game.model.PoolTableConfig
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class AimPrediction(
    val cueBallOrigin: Offset,
    val aimAngleRad: Float,
    val guidelineEnd: Offset,
    val ghostBallCenter: Offset? = null,
    val targetBall: Ball? = null,
    val targetDeflectionEnd: Offset? = null,
    val cueDeflectionEnd: Offset? = null
)

object AimPredictor {

    fun calculateAim(
        cueBall: Ball,
        aimAngleRad: Float,
        balls: List<Ball>
    ): AimPrediction {
        val origin = Offset(cueBall.x, cueBall.y)
        val dirX = cos(aimAngleRad)
        val dirY = sin(aimAngleRad)
        val r = PoolTableConfig.BALL_RADIUS
        val r2 = r * 2f

        var closestDist = Float.MAX_VALUE
        var hitTargetBall: Ball? = null
        var ghostCenter: Offset? = null

        // Test ray against all other active balls
        for (b in balls) {
            if (b.isPotted || b.isCueBall) continue

            // Vector from cue ball to target ball
            val toBx = b.x - origin.x
            val toBy = b.y - origin.y

            // Projection of toB onto ray direction
            val proj = toBx * dirX + toBy * dirY
            if (proj <= 0f) continue // behind cue ball

            // Perpendicular distance squared from ball center to ray
            val perpDistSq = (toBx * toBx + toBy * toBy) - (proj * proj)
            val radiusSumSq = r2 * r2

            if (perpDistSq < radiusSumSq) {
                // Ray intersects the target ball's collision circle
                val backDist = sqrt(radiusSumSq - perpDistSq)
                val distToGhost = proj - backDist

                if (distToGhost in 0f..closestDist) {
                    closestDist = distToGhost
                    hitTargetBall = b
                    ghostCenter = Offset(origin.x + dirX * distToGhost, origin.y + dirY * distToGhost)
                }
            }
        }

        if (ghostCenter != null && hitTargetBall != null) {
            // Target ball deflection line (along vector from ghost ball center to target ball center)
            val tdx = hitTargetBall.x - ghostCenter.x
            val tdy = hitTargetBall.y - ghostCenter.y
            val tDist = sqrt(tdx * tdx + tdy * tdy)

            val targetDeflectionEnd = if (tDist > 0.001f) {
                val tNormX = tdx / tDist
                val tNormY = tdy / tDist
                Offset(hitTargetBall.x + tNormX * 120f, hitTargetBall.y + tNormY * 120f)
            } else null

            // Cue ball deflection (tangent to collision line)
            val cueDeflectionEnd = Offset(ghostCenter.x + dirX * 30f, ghostCenter.y + dirY * 30f)

            return AimPrediction(
                cueBallOrigin = origin,
                aimAngleRad = aimAngleRad,
                guidelineEnd = ghostCenter,
                ghostBallCenter = ghostCenter,
                targetBall = hitTargetBall,
                targetDeflectionEnd = targetDeflectionEnd,
                cueDeflectionEnd = cueDeflectionEnd
            )
        } else {
            // No ball hit, find ray intersection with table cushions
            val maxRayLength = 1200f
            val endPoint = Offset(origin.x + dirX * maxRayLength, origin.y + dirY * maxRayLength)
            return AimPrediction(
                cueBallOrigin = origin,
                aimAngleRad = aimAngleRad,
                guidelineEnd = endPoint
            )
        }
    }
}
