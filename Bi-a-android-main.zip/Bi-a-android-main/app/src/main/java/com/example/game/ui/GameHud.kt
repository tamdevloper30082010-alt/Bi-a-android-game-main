package com.example.game.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.model.Ball
import com.example.game.model.PlayerId
import com.example.game.model.PlayerInfo
import kotlin.math.PI

/**
 * Vertical sidebar HUD, designed to sit alongside the pool table in
 * landscape orientation (the game is locked to landscape). Everything is
 * stacked in a single scrollable column so it never gets clipped on
 * shorter landscape screens.
 */
@Composable
fun GameHud(
    player1: PlayerInfo,
    player2: PlayerInfo,
    currentTurn: PlayerId,
    balls: List<Ball>,
    hasBallInHand: Boolean,
    isBreakShot: Boolean,
    isAiTurn: Boolean,
    canAim: Boolean,
    aimAngleRad: Float,
    shotPower: Float,
    soundEnabled: Boolean,
    recentLog: String,
    isMicEnabled: Boolean = false,
    isCameraEnabled: Boolean = false,
    onAngleChange: (Float) -> Unit,
    onPowerChange: (Float) -> Unit,
    onShootClick: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleMic: () -> Unit = {},
    onToggleCamera: () -> Unit = {},
    onConfirmBallInHand: () -> Unit = {},
    onQuickChat: (String) -> Unit = {},
    onOpenChat: () -> Unit,
    onLeaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // 1. Player badges, stacked vertically to fit a narrow sidebar
        PlayerBadge(
            player = player1,
            isActive = currentTurn == PlayerId.PLAYER_1,
            balls = balls,
            modifier = Modifier.fillMaxWidth()
        )
        PlayerBadge(
            player = player2,
            isActive = currentTurn == PlayerId.PLAYER_2,
            balls = balls,
            modifier = Modifier.fillMaxWidth()
        )

        // 2. Turn status banner
        Surface(
            color = Color(0x33000000),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = when {
                    isAiTurn -> "🤖 Máy đang ngắm..."
                    isBreakShot -> "🎱 Cú phá bi"
                    currentTurn == PlayerId.PLAYER_1 -> "Lượt ${player1.name}"
                    else -> "Lượt ${player2.name}"
                },
                color = Color(0xFFFBBF24),
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        // 3. Toolbar icons: mic / camera / sound / chat / leave
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleMic,
                modifier = Modifier.size(30.dp).testTag("mic_toggle_btn")
            ) {
                Icon(
                    imageVector = if (isMicEnabled) Icons.Default.Mic else Icons.Default.MicOff,
                    contentDescription = "Bật/Tắt Micro",
                    tint = if (isMicEnabled) Color(0xFF10B981) else Color(0xFFEF4444),
                    modifier = Modifier.size(17.dp)
                )
            }
            IconButton(
                onClick = onToggleCamera,
                modifier = Modifier.size(30.dp).testTag("camera_toggle_btn")
            ) {
                Icon(
                    imageVector = if (isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                    contentDescription = "Bật/Tắt Camera",
                    tint = if (isCameraEnabled) Color(0xFF38BDF8) else Color(0xFF94A3B8),
                    modifier = Modifier.size(17.dp)
                )
            }
            IconButton(
                onClick = onToggleSound,
                modifier = Modifier.size(30.dp).testTag("sound_toggle_btn")
            ) {
                Icon(
                    imageVector = if (soundEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                    contentDescription = "Bật/Tắt âm thanh",
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }
            IconButton(
                onClick = onOpenChat,
                modifier = Modifier.size(30.dp).testTag("chat_toggle_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Chat,
                    contentDescription = "Trò chuyện",
                    tint = Color.White,
                    modifier = Modifier.size(17.dp)
                )
            }
            IconButton(
                onClick = onLeaveClick,
                modifier = Modifier.size(30.dp).testTag("leave_match_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Rời phòng",
                    tint = Color(0xFFF87171),
                    modifier = Modifier.size(17.dp)
                )
            }
        }

        // 4. Ball-in-Hand Alert Banner with Confirm Button
        AnimatedVisibility(
            visible = hasBallInHand,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                color = Color(0xFF047857),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "✋ Chạm / kéo bi cái đến vị trí hợp lệ",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onConfirmBallInHand,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(28.dp).fillMaxWidth()
                    ) {
                        Text("✓ KHÓA BI", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 5. Angle control
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x880F1E17), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            val angleDeg = ((aimAngleRad * 180f / PI.toFloat()) % 360f).let { if (it < 0) it + 360f else it }
            Text(
                text = "Góc: ${angleDeg.toInt()}°",
                color = Color(0xFFFDE68A),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = {
                        var newA = aimAngleRad - (1f * PI.toFloat() / 180f)
                        if (newA < 0) newA += 2f * PI.toFloat()
                        onAngleChange(newA)
                    },
                    enabled = canAim,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Giảm góc", tint = Color.White)
                }
                Slider(
                    value = angleDeg,
                    onValueChange = { deg -> onAngleChange(deg * PI.toFloat() / 180f) },
                    valueRange = 0f..359f,
                    enabled = canAim,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFF38BDF8),
                        activeTrackColor = Color(0xFF38BDF8)
                    ),
                    modifier = Modifier.weight(1f).height(24.dp)
                )
                IconButton(
                    onClick = {
                        var newA = aimAngleRad + (1f * PI.toFloat() / 180f)
                        if (newA >= 2f * PI.toFloat()) newA -= 2f * PI.toFloat()
                        onAngleChange(newA)
                    },
                    enabled = canAim,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Tăng góc", tint = Color.White)
                }
            }
        }

        // 6. Power control
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0x880F1E17), RoundedCornerShape(10.dp))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Lực: ${(shotPower * 100).toInt()}%",
                color = Color(0xFF34D399),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Slider(
                value = shotPower,
                onValueChange = onPowerChange,
                valueRange = 0.05f..1.0f,
                enabled = canAim,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF10B981),
                    activeTrackColor = Color(0xFF10B981)
                ),
                modifier = Modifier.fillMaxWidth().height(24.dp)
            )
        }

        // 7. Big Shoot Button
        Button(
            onClick = onShootClick,
            enabled = canAim && !isAiTurn,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF059669),
                disabledContainerColor = Color(0x33FFFFFF)
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .testTag("shoot_button")
        ) {
            Text(
                text = "🎱 ĐÁNH",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                color = Color.White
            )
        }

        // 8. Live Event Log Ticker
        if (recentLog.isNotBlank()) {
            Text(
                text = recentLog,
                color = Color(0xFFCBD5E1),
                fontSize = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 9. Quick Danmaku / Chat phrases
        QuickChatRow(onQuickChat = onQuickChat)
    }
}

@Composable
private fun QuickChatRow(onQuickChat: (String) -> Unit) {
    val quickPhrases = listOf(
        "🎱 Phá bi nào!",
        "🔥 Đẹp mắt quá!",
        "🎯 Siêu phẩm!",
        "😅 Lắc cơ rồi",
        "👏 Hay lắm!",
        "😎 Chúc may mắn"
    )
    // Bug fix: this row used to overflow with no way to reach the later
    // phrases on narrow screens. Wrapping it in horizontal scroll ensures
    // every quick-chat phrase stays reachable regardless of sidebar width.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (phrase in quickPhrases) {
            Surface(
                color = Color(0x2E000000),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0x44FFFFFF)),
                modifier = Modifier.clickable { onQuickChat(phrase) }
            ) {
                Text(
                    text = phrase,
                    color = Color(0xFFE2E8F0),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
fun PlayerBadge(
    player: PlayerInfo,
    isActive: Boolean,
    balls: List<Ball>,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isActive) Color(0xFFF59E0B) else Color(0x33FFFFFF)
    val bgColor = if (isActive) Color(0xFF1B3828) else Color(0xFF0F1E17)

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(if (isActive) 2.dp else 1.dp, borderColor),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(if (player.isAi) Color(0xFF6366F1) else Color(0xFF10B981)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (player.isAi) Icons.Default.SmartToy else Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Text(
                    text = player.name,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Text(
                text = player.group?.displayName ?: "Chưa chọn nhóm",
                color = Color(0xFF94A3B8),
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )

            // Mini Remaining Balls rack
            if (player.group != null) {
                val myBalls = balls.filter { !it.isPotted && it.group == player.group }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.padding(top = 2.dp)
                ) {
                    if (myBalls.isEmpty()) {
                        // Cleared group, show 8-ball requirement
                        val eightBall = balls.find { it.isEightBall }
                        val eightPotted = eightBall?.isPotted == true
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (eightPotted) Color.Gray else Color.Black)
                                .border(1.dp, Color(0xFFFBBF24), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("8", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        for (b in myBalls.take(7)) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(b.baseColor)
                                    .border(0.5.dp, Color.White, CircleShape)
                            )
                        }
                    }
                }
            }
        }
    }
}
