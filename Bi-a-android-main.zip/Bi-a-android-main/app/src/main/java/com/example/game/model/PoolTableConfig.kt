package com.example.game.model

import androidx.compose.ui.geometry.Offset

/**
 * Billiards Table Geometry & Physics Configurations
 * Standard virtual coordinate system: 1000 x 500 units (2:1 aspect ratio)
 */
object PoolTableConfig {
    const val WIDTH = 1000f
    const val HEIGHT = 500f
    const val RAIL_WIDTH = 32f

    // Cushion boundaries for balls
    const val PLAY_LEFT = RAIL_WIDTH
    const val PLAY_TOP = RAIL_WIDTH
    const val PLAY_RIGHT = WIDTH - RAIL_WIDTH
    const val PLAY_BOTTOM = HEIGHT - RAIL_WIDTH

    const val BALL_RADIUS = 13.5f
    const val POCKET_RADIUS = 26f
    const val POCKET_MOUTH_RADIUS = 30f

    // Physics parameters
    const val FRICTION = 0.992f
    // Constant rolling-friction deceleration (units/frame), applied on top of the
    // multiplicative FRICTION above. Pure multiplicative (exponential) decay alone
    // has an unbounded tail — a ball never truly "reaches zero", it just gets
    // asymptotically slower, which reads as rolling forever. Real rolling
    // friction decelerates a ball at close to a constant rate, so adding a small
    // constant subtraction here guarantees every shot comes to a natural, bounded
    // stop (a few seconds) instead of coasting indefinitely.
    const val ROLLING_DECEL = 0.10f
    const val MIN_SPEED = 0.045f
    const val CUSHION_RESTITUTION = 0.85f
    const val BALL_RESTITUTION = 0.98f
    const val MAX_SHOT_SPEED = 24f
    const val MAX_DRAG_DISTANCE = 200f
    const val SUBSTEPS = 8

    // Head string line for break shot and rack placement
    val HEAD_SPOT = Offset(PLAY_LEFT + (PLAY_RIGHT - PLAY_LEFT) * 0.25f, (PLAY_TOP + PLAY_BOTTOM) * 0.5f)
    val FOOT_SPOT = Offset(PLAY_LEFT + (PLAY_RIGHT - PLAY_LEFT) * 0.72f, (PLAY_TOP + PLAY_BOTTOM) * 0.5f)

    // 6 Pocket locations
    val POCKETS = listOf(
        Offset(PLAY_LEFT + 2f, PLAY_TOP + 2f),                 // Top-Left Corner
        Offset((PLAY_LEFT + PLAY_RIGHT) * 0.5f, PLAY_TOP - 4f), // Top-Center
        Offset(PLAY_RIGHT - 2f, PLAY_TOP + 2f),                // Top-Right Corner
        Offset(PLAY_LEFT + 2f, PLAY_BOTTOM - 2f),              // Bottom-Left Corner
        Offset((PLAY_LEFT + PLAY_RIGHT) * 0.5f, PLAY_BOTTOM + 4f), // Bottom-Center
        Offset(PLAY_RIGHT - 2f, PLAY_BOTTOM - 2f)              // Bottom-Right Corner
    )
}
