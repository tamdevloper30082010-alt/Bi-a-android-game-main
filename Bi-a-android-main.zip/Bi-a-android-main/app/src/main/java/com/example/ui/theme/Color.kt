package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldLight = Color(0xFF34D399)

val GoldAccent = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFDE68A)

val TableFelt = Color(0xFF0E6B3A)
val TableFeltDark = Color(0xFF0A4F2A)
val TableWoodRail = Color(0xFF45220C)
val TableWoodRailDark = Color(0xFF2A1407)

val DarkBg = Color(0xFF09140E)
val DarkSurface = Color(0xFF112219)
val DarkSurfaceElevated = Color(0xFF183226)

val TextPrimary = Color(0xFFF1F5F3)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val BallCue = Color(0xFFF8FAFC)
val BallYellow = Color(0xFFEAB308)
val BallBlue = Color(0xFF2563EB)
val BallRed = Color(0xFFDC2626)
val BallPurple = Color(0xFF7C3AED)
val BallOrange = Color(0xFFEA580C)
val BallGreen = Color(0xFF16A34A)
val BallMaroon = Color(0xFF881337)
val BallBlack = Color(0xFF0F172A)

