package com.example.game.ai

import androidx.compose.ui.geometry.Offset
import com.example.game.model.AiDifficulty
import com.example.game.model.Ball
import com.example.game.model.BallGroup
import com.example.game.model.PoolTableConfig
import com.example.game.physics.PoolPhysicsEngine
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class AiShotDecision(
    val angleRad: Float,
    val power: Float,
    val targetBallNum: Int? = null,
    val targetPocket: Offset? = null,
    val ballInHandPlacement: Offset? = null
)

object PoolAi {

    fun decideShot(
        balls: List<Ball>,
        aiGroup: BallGroup?,
        difficulty: AiDifficulty,
        isBreakShot: Boolean,
        hasBallInHand: Boolean
    ): AiShotDecision {
        val cueBall = balls.find { it.isCueBall } ?: return AiShotDecision(0f, 0.5f)

        // 1. If Break Shot: smash the apex with high power
        if (isBreakShot) {
            val apex = balls.find { it.num == 1 } ?: balls.firstOrNull { !it.isCueBall }
            val targetPos = apex?.position ?: PoolTableConfig.FOOT_SPOT
            val angle = atan2(targetPos.y - cueBall.y, targetPos.x - cueBall.x)
            val jitter = when (difficulty) {
                AiDifficulty.EASY -> Random.nextFloat() * 0.06f - 0.03f
                AiDifficulty.MEDIUM -> Random.nextFloat() * 0.03f - 0.015f
                AiDifficulty.HARD -> Random.nextFloat() * 0.008f - 0.004f
            }
            return AiShotDecision(angle + jitter, 0.95f)
        }

        // 2. Identify candidate target balls
        val candidateBalls = getEligibleTargetBalls(balls, aiGroup)

        // 3. If Ball In Hand: pick best target, position cue ball directly aligned with target to pocket
        var ballInHandPos: Offset? = null
        if (hasBallInHand && candidateBalls.isNotEmpty()) {
            val chosenTarget = candidateBalls.first()
            val closestPocket = PoolTableConfig.POCKETS.minByOrNull { p ->
                val dx = chosenTarget.x - p.x
                val dy = chosenTarget.y - p.y
                dx * dx + dy * dy
            } ?: PoolTableConfig.POCKETS[0]

            val dirX = chosenTarget.x - closestPocket.x
            val dirY = chosenTarget.y - closestPocket.y
            val dist = sqrt(dirX * dirX + dirY * dirY)
            if (dist > 0.001f) {
                val testX = chosenTarget.x + (dirX / dist) * 70f
                val testY = chosenTarget.y + (dirY / dist) * 70f
                if (PoolPhysicsEngine.isValidCuePlacement(testX, testY, balls)) {
                    ballInHandPos = Offset(testX, testY)
                }
            }
        }

        val cuePos = ballInHandPos ?: Offset(cueBall.x, cueBall.y)

        // 4. Evaluate all candidate shots
        data class CandidateShot(
            val ball: Ball,
            val pocket: Offset,
            val aimAngle: Float,
            val power: Float,
            val score: Float
        )

        val shots = mutableListOf<CandidateShot>()

        for (target in candidateBalls) {
            for (pocket in PoolTableConfig.POCKETS) {
                // Vector from target to pocket
                val tpX = pocket.x - target.x
                val tpY = pocket.y - target.y
                val tpDist = sqrt(tpX * tpX + tpY * tpY)
                if (tpDist < 1f) continue

                val tpNormX = tpX / tpDist
                val tpNormY = tpY / tpDist

                // Ghost ball location: cue ball must strike target on opposite side of pocket
                val ghostX = target.x - tpNormX * (PoolTableConfig.BALL_RADIUS * 2f)
                val ghostY = target.y - tpNormY * (PoolTableConfig.BALL_RADIUS * 2f)

                // Vector from cue to ghost ball
                val cgX = ghostX - cuePos.x
                val cgY = ghostY - cuePos.y
                val cgDist = sqrt(cgX * cgX + cgY * cgY)
                if (cgDist < 1f) continue

                val cgNormX = cgX / cgDist
                val cgNormY = cgY / cgDist

                // Cut angle: dot product between cue-ghost and target-pocket
                val dot = cgNormX * tpNormX + cgNormY * tpNormY
                // dot = 1.0 means straight on, dot < 0 means aiming away from pocket
                if (dot <= 0.15f) continue // Too sharp of a cut angle

                // Check line of sight from target to pocket (no obstacle balls in between)
                if (isPathBlocked(target.position, pocket, balls, listOf(target.num, 0))) continue

                // Check line of sight from cue to ghost ball
                if (isPathBlocked(cuePos, Offset(ghostX, ghostY), balls, listOf(target.num, 0))) continue

                val aimAngle = atan2(cgY, cgX)
                val basePower = ((cgDist + tpDist) / 1000f * 0.6f + 0.25f).coerceIn(0.2f, 0.9f)

                // Scoring: straight shots (dot ~ 1) + close to pocket + close to cue
                val score = dot * 100f - (tpDist * 0.05f) - (cgDist * 0.02f)
                shots.add(CandidateShot(target, pocket, aimAngle, basePower, score))
            }
        }

        // Sort by highest score
        shots.sortByDescending { it.score }

        val chosenShot = when {
            shots.isEmpty() -> {
                // Fallback: aim at the closest candidate ball to nudge it
                val fallbackTarget = candidateBalls.minByOrNull { b ->
                    val dx = b.x - cuePos.x
                    val dy = b.y - cuePos.y
                    dx * dx + dy * dy
                }
                if (fallbackTarget != null) {
                    val angle = atan2(fallbackTarget.y - cuePos.y, fallbackTarget.x - cuePos.x)
                    CandidateShot(fallbackTarget, PoolTableConfig.POCKETS[0], angle, 0.45f, 0f)
                } else {
                    CandidateShot(balls.first { !it.isCueBall }, PoolTableConfig.POCKETS[0], 0f, 0.4f, 0f)
                }
            }
            difficulty == AiDifficulty.EASY && shots.size > 2 -> {
                // Easy AI might pick second or third best shot
                shots[Random.nextInt(minOf(3, shots.size))]
            }
            else -> shots.first()
        }

        // Apply difficulty jitter
        val jitterMagnitude = when (difficulty) {
            AiDifficulty.EASY -> 0.05f
            AiDifficulty.MEDIUM -> 0.018f
            AiDifficulty.HARD -> 0.003f
        }
        val angleJitter = (Random.nextFloat() * 2f - 1f) * jitterMagnitude
        val powerJitter = (Random.nextFloat() * 2f - 1f) * 0.05f

        val finalAngle = (chosenShot.aimAngle + angleJitter).let {
            var a = it % (2f * PI.toFloat())
            if (a < 0) a += 2f * PI.toFloat()
            a
        }
        val finalPower = (chosenShot.power + powerJitter).coerceIn(0.15f, 0.95f)

        return AiShotDecision(
            angleRad = finalAngle,
            power = finalPower,
            targetBallNum = chosenShot.ball.num,
            targetPocket = chosenShot.pocket,
            ballInHandPlacement = ballInHandPos
        )
    }

    private fun getEligibleTargetBalls(balls: List<Ball>, aiGroup: BallGroup?): List<Ball> {
        val active = balls.filter { !it.isPotted && !it.isCueBall }
        if (aiGroup == null) {
            // Open table: can target any ball 1..15 except 8
            return active.filter { it.num != 8 }
        }

        val myGroupBalls = active.filter { it.group == aiGroup }
        return if (myGroupBalls.isNotEmpty()) {
            myGroupBalls
        } else {
            // Cleared group, must target 8 ball
            active.filter { it.isEightBall }
        }
    }

    private fun isPathBlocked(
        start: Offset,
        end: Offset,
        balls: List<Ball>,
        ignoredBallNums: List<Int>
    ): Boolean {
        val dx = end.x - start.x
        val dy = end.y - start.y
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 1f) return false

        val dirX = dx / dist
        val dirY = dy / dist
        val r2 = PoolTableConfig.BALL_RADIUS * 2f

        for (b in balls) {
            if (b.isPotted || b.num in ignoredBallNums) continue

            val toBx = b.x - start.x
            val toBy = b.y - start.y
            val proj = toBx * dirX + toBy * dirY

            // If ball is along the segment between start and end
            if (proj in 5f..(dist - 5f)) {
                val perpDistSq = (toBx * toBx + toBy * toBy) - (proj * proj)
                if (perpDistSq < r2 * r2) {
                    return true // Blocked by ball b
                }
            }
        }
        return false
    }
}
