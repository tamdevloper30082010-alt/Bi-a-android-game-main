package com.example.game.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun PlayerMediaCommBar(
    isMicEnabled: Boolean,
    isCameraEnabled: Boolean,
    onToggleMic: () -> Unit,
    onToggleCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onToggleMic()
        }
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xBB0B1B13))
            .border(1.dp, Color(0x3334D399), RoundedCornerShape(24.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Mic button
        IconButton(
            onClick = {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPermission) {
                    onToggleMic()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            },
            modifier = Modifier
                .size(34.dp)
                .testTag("media_mic_toggle")
        ) {
            Icon(
                imageVector = if (isMicEnabled) Icons.Default.Mic else Icons.Default.MicOff,
                contentDescription = "Bật/Tắt Micro",
                tint = if (isMicEnabled) Color(0xFF10B981) else Color(0xFFEF4444),
                modifier = Modifier.size(18.dp)
            )
        }

        // Camera button
        IconButton(
            onClick = onToggleCamera,
            modifier = Modifier
                .size(34.dp)
                .testTag("media_camera_toggle")
        ) {
            Icon(
                imageVector = if (isCameraEnabled) Icons.Default.Videocam else Icons.Default.VideocamOff,
                contentDescription = "Bật/Tắt Camera",
                tint = if (isCameraEnabled) Color(0xFF38BDF8) else Color(0xFF94A3B8),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun CameraPiPOverlay(
    isCameraEnabled: Boolean,
    isMicEnabled: Boolean,
    playerName: String,
    opponentName: String,
    onCloseCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!isCameraEnabled) return

    var isFrontCamera by remember { mutableStateOf(true) }
    var isMinimized by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val micPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "micPulse"
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xDD0F1E17)),
        modifier = modifier
            .width(if (isMinimized) 120.dp else 150.dp)
            .border(1.5.dp, Color(0xFF10B981), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header: Name & Controls
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEF4444))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LIVE",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { isFrontCamera = !isFrontCamera },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = "Đổi Camera",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = { isMinimized = !isMinimized },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isMinimized) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Thu nhỏ",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onCloseCamera,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng Camera",
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            if (!isMinimized) {
                Spacer(modifier = Modifier.height(4.dp))

                // Camera Preview Viewfinder
                Box(
                    modifier = Modifier
                        .height(110.dp)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black)
                ) {
                    PlayerLiveCameraView(
                        isFrontCamera = isFrontCamera,
                        isMicEnabled = isMicEnabled
                    )

                    // Audio Speaking Wave Badge
                    if (isMicEnabled) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0x9910B981),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp)
                                .scale(micPulse)
                                .size(20.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Đang nói",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = playerName,
                    color = Color(0xFFFBBF24),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun PlayerLiveCameraView(
    isFrontCamera: Boolean,
    isMicEnabled: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "camAnim")
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanLine"
    )

    val wavePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wavePulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0F261B),
                        Color(0xFF081710),
                        Color(0xFF030A06)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Subtle HUD grid / reticle overlay
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Corner brackets
            val cornerLen = 14f
            val cornerColor = Color(0x6634D399)
            val strokeW = 1.5f

            // Top-left
            drawLine(cornerColor, Offset(6f, 6f), Offset(6f + cornerLen, 6f), strokeW)
            drawLine(cornerColor, Offset(6f, 6f), Offset(6f, 6f + cornerLen), strokeW)
            // Top-right
            drawLine(cornerColor, Offset(w - 6f, 6f), Offset(w - 6f - cornerLen, 6f), strokeW)
            drawLine(cornerColor, Offset(w - 6f, 6f), Offset(w - 6f, 6f + cornerLen), strokeW)
            // Bottom-left
            drawLine(cornerColor, Offset(6f, h - 6f), Offset(6f + cornerLen, h - 6f), strokeW)
            drawLine(cornerColor, Offset(6f, h - 6f), Offset(6f, h - 6f - cornerLen), strokeW)
            // Bottom-right
            drawLine(cornerColor, Offset(w - 6f, h - 6f), Offset(w - 6f - cornerLen, h - 6f), strokeW)
            drawLine(cornerColor, Offset(w - 6f, h - 6f), Offset(w - 6f, h - 6f - cornerLen), strokeW)

            // Scanning line
            val scanY = h * scanLineProgress
            drawLine(
                color = Color(0x4410B981),
                start = Offset(0f, scanY),
                end = Offset(w, scanY),
                strokeWidth = 2f
            )
        }

        // Center Player Avatar / Camera Silhouette
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF133B27))
                    .border(
                        1.5.dp,
                        if (isMicEnabled) Color(0xFF10B981) else Color(0x5534D399),
                        CircleShape
                    )
            ) {
                if (isMicEnabled) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .scale(wavePulse)
                            .clip(CircleShape)
                            .border(1.dp, Color(0x3310B981), CircleShape)
                    )
                }

                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = null,
                    tint = Color(0xFFE2E8F0),
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isFrontCamera) "Cam Trước" else "Cam Sau",
                color = Color(0xFF86EFAC),
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun VoiceIndicatorOverlay(
    isMicActive: Boolean,
    playerName: String,
    modifier: Modifier = Modifier
) {
    if (!isMicActive) return
    val infiniteTransition = rememberInfiniteTransition(label = "voicePulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Surface(
        color = Color(0xDD0F2E1E),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF10B981)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .scale(pulse)
                    .clip(CircleShape)
                    .background(Color(0xFF10B981))
            )
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Micro đang bật",
                tint = Color(0xFF10B981),
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = "$playerName (Mic On)",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
