package com.example.game.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MusicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Sports
import androidx.compose.material.icons.filled.SportsScore
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.game.model.AiDifficulty
import com.example.game.model.GameMode

@Composable
fun MainMenuScreen(
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    onStartPassAndPlay: (String, String) -> Unit,
    onStartVsAi: (String, AiDifficulty) -> Unit,
    onStartPractice: () -> Unit,
    onHostP2PRoom: (String) -> Unit,
    onJoinP2PRoom: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRulesDialog by remember { mutableStateOf(false) }
    var showP2PDialog by remember { mutableStateOf(false) }
    var showAiConfigDialog by remember { mutableStateOf(false) }
    var showPassAndPlayDialog by remember { mutableStateOf(false) }

    var playerName by remember { mutableStateOf("Cơ thủ 1") }
    var player2Name by remember { mutableStateOf("Cơ thủ 2") }

    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF0F2A1E), Color(0xFF08150E)),
                    radius = 1200f
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Toolbar: Sound & Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onToggleSound) {
                    Icon(
                        imageVector = if (soundEnabled) Icons.Default.MusicNote else Icons.Default.MusicOff,
                        contentDescription = "Âm thanh",
                        tint = Color.White
                    )
                }
                IconButton(onClick = onToggleHaptics) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Rung phản hồi",
                        tint = if (hapticsEnabled) Color(0xFF10B981) else Color.Gray
                    )
                }
                IconButton(onClick = { showRulesDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Luật chơi",
                        tint = Color(0xFFFBBF24)
                    )
                }
            }

            // Hero Branding Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_billiards_logo),
                    contentDescription = "Billiards 8-Ball Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .border(2.dp, Color(0xFFF59E0B), RoundedCornerShape(24.dp))
                )

                Text(
                    text = "BI-A 8 BI NATIVE",
                    fontWeight = FontWeight.Black,
                    fontSize = 26.sp,
                    color = Color.White,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "Vật lý chân thực • 100% Native Jetpack Compose • Chuẩn luật WPA",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Game Mode Cards Grid
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .widthIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuModeCard(
                    title = "2 Người chơi (Pass & Play)",
                    subtitle = "Chơi đối kháng trên cùng thiết bị với bạn bè",
                    icon = Icons.Default.Groups,
                    accentColor = Color(0xFF10B981),
                    onClick = { showPassAndPlayDialog = true },
                    testTag = "mode_pass_and_play"
                )

                MenuModeCard(
                    title = "Đấu với Máy (Vs AI)",
                    subtitle = "So tài cùng trí tuệ nhân tạo (Dễ / Vừa / Cao thủ)",
                    icon = Icons.Default.Psychology,
                    accentColor = Color(0xFF6366F1),
                    onClick = { showAiConfigDialog = true },
                    testTag = "mode_vs_ai"
                )

                MenuModeCard(
                    title = "Phòng đấu P2P (WiFi / LAN)",
                    subtitle = "Kết nối trực tiếp 2 thiết bị qua mã PIN 3 số",
                    icon = Icons.Default.Cast,
                    accentColor = Color(0xFFF59E0B),
                    onClick = { showP2PDialog = true },
                    testTag = "mode_p2p"
                )

                MenuModeCard(
                    title = "Luyện tập tự do",
                    subtitle = "Tập ngắm bắn, thử các đường cơ và góc bi",
                    icon = Icons.Default.Sports,
                    accentColor = Color(0xFF38BDF8),
                    onClick = onStartPractice,
                    testTag = "mode_practice"
                )
            }
        }
    }

    // Pass and play player name dialog
    if (showPassAndPlayDialog) {
        Dialog(onDismissRequest = { showPassAndPlayDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E17)),
                modifier = Modifier.padding(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "👥 Thiết lập trận đấu 2 người",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )

                    OutlinedTextField(
                        value = playerName,
                        onValueChange = { playerName = it },
                        label = { Text("Tên người chơi 1") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = player2Name,
                        onValueChange = { player2Name = it },
                        label = { Text("Tên người chơi 2") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            showPassAndPlayDialog = false
                            onStartPassAndPlay(
                                playerName.ifBlank { "Cơ thủ 1" },
                                player2Name.ifBlank { "Cơ thủ 2" }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("BẮT ĐẦU VÁN ĐẤU", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // AI Config Dialog
    if (showAiConfigDialog) {
        var selectedDifficulty by remember { mutableStateOf(AiDifficulty.MEDIUM) }
        Dialog(onDismissRequest = { showAiConfigDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E17)),
                modifier = Modifier.padding(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🤖 Đấu với Máy tính",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )

                    OutlinedTextField(
                        value = playerName,
                        onValueChange = { playerName = it },
                        label = { Text("Tên của bạn") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Chọn độ khó:", color = Color.LightGray, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiDifficulty.entries.forEach { diff ->
                            val isSelected = selectedDifficulty == diff
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isSelected) Color(0xFF6366F1) else Color(0x33FFFFFF),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedDifficulty = diff }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = diff.label,
                                    color = Color.White,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            showAiConfigDialog = false
                            onStartVsAi(playerName.ifBlank { "Cơ thủ" }, selectedDifficulty)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("BẮT ĐẦU VÁN ĐẤU", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // P2P Setup Dialog
    if (showP2PDialog) {
        var joinCode by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showP2PDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E17)),
                modifier = Modifier.padding(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "🌐 Phòng đấu P2P / Mạng LAN",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )

                    OutlinedTextField(
                        value = playerName,
                        onValueChange = { playerName = it },
                        label = { Text("Tên của bạn") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            showP2PDialog = false
                            onHostP2PRoom(playerName.ifBlank { "Chủ phòng" })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TẠO PHÒNG MỚI (LÀM CHỦ PHÒNG)", fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(1.dp)
                                .background(Color(0x33FFFFFF))
                        )
                        Text(
                            text = " HOẶC THAM GIA ",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 6.dp)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(1.dp)
                                .background(Color(0x33FFFFFF))
                        )
                    }

                    OutlinedTextField(
                        value = joinCode,
                        onValueChange = { joinCode = it },
                        label = { Text("Mã phòng (3 số) hoặc IP chủ phòng") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Button(
                        onClick = {
                            showP2PDialog = false
                            onJoinP2PRoom(
                                joinCode.ifBlank { "001" },
                                playerName.ifBlank { "Khách" }
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("THAM GIA PHÒNG", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Rules Dialog
    if (showRulesDialog) {
        Dialog(onDismissRequest = { showRulesDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E17)),
                modifier = Modifier.padding(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "📖 Luật chơi Bi-a 8 Bi Quốc Tế",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color(0xFFFBBF24)
                    )

                    Text(
                        text = "1. Bàn cờ & Nhóm bi:\n" +
                                "• 1 bi cái trắng (số 0)\n" +
                                "• Bi trơn (Solid): số 1 đến 7\n" +
                                "• Bi sọc (Stripe): số 9 đến 15\n" +
                                "• Bi số 8 màu đen quyết định thắng thua.\n\n" +
                                "2. Phân nhóm:\n" +
                                "Bàn mở ban đầu. Người chơi đầu tiên đưa bi nhóm nào vào lỗ hợp lệ sau cú phá sẽ nhận nhóm đó.\n\n" +
                                "3. Lỗi phạm quy (Foul):\n" +
                                "• Bi cái vào lỗ (Scratch)\n" +
                                "• Không chạm bi mục tiêu nào\n" +
                                "• Chạm sai nhóm bi trước\n" +
                                "• Không có bi nào chạm băng sau va chạm.\n" +
                                "Khi đối thủ phạm quy, bạn được 'ĐẶT BI TỰ DO' bất kỳ đâu trên bàn.\n\n" +
                                "4. Điều kiện Thắng / Thua:\n" +
                                "• THẮNG: Dọn sạch nhóm bi của mình rồi ăn bi số 8 vào lỗ.\n" +
                                "• THUA: Ăn bi số 8 khi chưa dọn sạch nhóm, hoặc phạm quy khi đánh bi số 8.",
                        color = Color(0xFFE2E8F0),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )

                    Button(
                        onClick = { showRulesDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("ĐÃ HIỂU")
                    }
                }
            }
        }
    }
}

@Composable
fun MenuModeCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF112219),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FFFFFF)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accentColor.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
