package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.game.ai.PoolAi
import com.example.game.model.AiDifficulty
import com.example.game.model.Ball
import com.example.game.model.BallGroup
import com.example.game.model.ChatMessage
import com.example.game.model.GameMode
import com.example.game.model.PlayerId
import com.example.game.model.PlayerInfo
import com.example.game.model.PoolTableConfig
import com.example.game.model.ShotContext
import com.example.game.model.ShotEvent
import com.example.game.net.P2PConnectionState
import com.example.game.net.P2PManager
import com.example.game.net.P2PMessageListener
import com.example.game.physics.PoolPhysicsEngine
import com.example.game.rules.PoolRules
import com.example.game.sound.SoundManager
import com.example.game.ui.DanmakuItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class AppScreen {
    MAIN_MENU,
    IN_GAME,
    P2P_LOBBY
}

class GameViewModel(application: Application) : AndroidViewModel(application), P2PMessageListener {

    val soundManager = SoundManager(application)
    private val p2pManager = P2PManager(viewModelScope, this)

    private val _currentScreen = MutableStateFlow(AppScreen.MAIN_MENU)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _gameMode = MutableStateFlow(GameMode.PASS_AND_PLAY)
    val gameMode: StateFlow<GameMode> = _gameMode.asStateFlow()

    private val _aiDifficulty = MutableStateFlow(AiDifficulty.MEDIUM)
    val aiDifficulty: StateFlow<AiDifficulty> = _aiDifficulty.asStateFlow()

    private val _balls = MutableStateFlow<List<Ball>>(emptyList())
    val balls: StateFlow<List<Ball>> = _balls.asStateFlow()

    private val _player1 = MutableStateFlow(PlayerInfo(PlayerId.PLAYER_1, "Cơ thủ 1"))
    val player1: StateFlow<PlayerInfo> = _player1.asStateFlow()

    private val _player2 = MutableStateFlow(PlayerInfo(PlayerId.PLAYER_2, "Cơ thủ 2"))
    val player2: StateFlow<PlayerInfo> = _player2.asStateFlow()

    private val _currentTurn = MutableStateFlow(PlayerId.PLAYER_1)
    val currentTurn: StateFlow<PlayerId> = _currentTurn.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private val _hasBallInHand = MutableStateFlow(false)
    val hasBallInHand: StateFlow<Boolean> = _hasBallInHand.asStateFlow()

    private val _isBreakShot = MutableStateFlow(true)
    val isBreakShot: StateFlow<Boolean> = _isBreakShot.asStateFlow()

    private val _isGameOver = MutableStateFlow(false)
    val isGameOver: StateFlow<Boolean> = _isGameOver.asStateFlow()

    private val _winner = MutableStateFlow<PlayerId?>(null)
    val winner: StateFlow<PlayerId?> = _winner.asStateFlow()

    private val _gameOverReason = MutableStateFlow("")
    val gameOverReason: StateFlow<String> = _gameOverReason.asStateFlow()

    private val _aimAngleRad = MutableStateFlow(0f)
    val aimAngleRad: StateFlow<Float> = _aimAngleRad.asStateFlow()

    private val _shotPower = MutableStateFlow(0.5f)
    val shotPower: StateFlow<Float> = _shotPower.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _recentLog = MutableStateFlow("Chào mừng đến với Bi-a 8 Bi Native!")
    val recentLog: StateFlow<String> = _recentLog.asStateFlow()

    private val _danmakuItems = MutableStateFlow<List<DanmakuItem>>(emptyList())
    val danmakuItems: StateFlow<List<DanmakuItem>> = _danmakuItems.asStateFlow()

    private val _isMicEnabled = MutableStateFlow(false)
    val isMicEnabled: StateFlow<Boolean> = _isMicEnabled.asStateFlow()

    private val _isCameraEnabled = MutableStateFlow(false)
    val isCameraEnabled: StateFlow<Boolean> = _isCameraEnabled.asStateFlow()

    private var danmakuCounter = 0L
    private var lastLane = 0

    private val _p2pState = MutableStateFlow<P2PConnectionState>(P2PConnectionState.Idle)
    val p2pState: StateFlow<P2PConnectionState> = _p2pState.asStateFlow()

    private var activeShotContext: ShotContext? = null
    private var physicsJob: Job? = null
    private var aiThinkingJob: Job? = null

    init {
        resetTable()
    }

    fun setAim(angleRad: Float, power: Float) {
        if (_isSimulating.value || _isGameOver.value) return
        var normalizedAngle = angleRad % (2f * PI.toFloat())
        if (normalizedAngle < 0) normalizedAngle += 2f * PI.toFloat()

        _aimAngleRad.value = normalizedAngle
        _shotPower.value = power.coerceIn(0.05f, 1.0f)

        if (_gameMode.value == GameMode.P2P_LAN && p2pManager.isConnected) {
            p2pManager.sendAim(normalizedAngle, power)
        }
    }

    fun startPassAndPlay(p1Name: String, p2Name: String) {
        _gameMode.value = GameMode.PASS_AND_PLAY
        _player1.value = PlayerInfo(PlayerId.PLAYER_1, p1Name, isAi = false)
        _player2.value = PlayerInfo(PlayerId.PLAYER_2, p2Name, isAi = false)
        startNewMatch()
    }

    fun startVsAi(p1Name: String, difficulty: AiDifficulty) {
        _gameMode.value = GameMode.VS_AI
        _aiDifficulty.value = difficulty
        _player1.value = PlayerInfo(PlayerId.PLAYER_1, p1Name, isAi = false)
        _player2.value = PlayerInfo(PlayerId.PLAYER_2, "Máy (${difficulty.label})", isAi = true)
        startNewMatch()
    }

    fun startPractice() {
        _gameMode.value = GameMode.PRACTICE
        _player1.value = PlayerInfo(PlayerId.PLAYER_1, "Luyện tập", isAi = false)
        _player2.value = PlayerInfo(PlayerId.PLAYER_2, "Tập luyện", isAi = false)
        startNewMatch()
    }

    fun hostP2PRoom(playerName: String) {
        _gameMode.value = GameMode.P2P_LAN
        _player1.value = PlayerInfo(PlayerId.PLAYER_1, playerName, isAi = false)
        _currentScreen.value = AppScreen.P2P_LOBBY
        p2pManager.startHost(playerName) { newState ->
            _p2pState.value = newState
            if (newState is P2PConnectionState.Connected) {
                _player2.value = PlayerInfo(PlayerId.PLAYER_2, newState.peerName, isAi = false)
                startNewMatch()
            }
        }
    }

    fun joinP2PRoom(roomCodeOrIp: String, playerName: String) {
        _gameMode.value = GameMode.P2P_LAN
        _player2.value = PlayerInfo(PlayerId.PLAYER_2, playerName, isAi = false)
        _currentScreen.value = AppScreen.P2P_LOBBY
        p2pManager.joinRoom(roomCodeOrIp, playerName) { newState ->
            _p2pState.value = newState
            if (newState is P2PConnectionState.Connected) {
                _player1.value = PlayerInfo(PlayerId.PLAYER_1, newState.peerName, isAi = false)
                startNewMatch()
            }
        }
    }

    fun cancelP2PLobby() {
        p2pManager.disconnect()
        _currentScreen.value = AppScreen.MAIN_MENU
    }

    fun returnToMainMenu() {
        physicsJob?.cancel()
        aiThinkingJob?.cancel()
        p2pManager.disconnect()
        _currentScreen.value = AppScreen.MAIN_MENU
    }

    fun startNewMatch() {
        physicsJob?.cancel()
        aiThinkingJob?.cancel()
        resetTable()
        _currentTurn.value = PlayerId.PLAYER_1
        _isGameOver.value = false
        _winner.value = null
        _gameOverReason.value = ""
        _isBreakShot.value = true
        _hasBallInHand.value = false
        _player1.value = _player1.value.copy(group = null)
        _player2.value = _player2.value.copy(group = null)
        _currentScreen.value = AppScreen.IN_GAME
        _recentLog.value = "Ván mới bắt đầu. ${_player1.value.name} giao bóng."

        // Default aim towards foot spot
        _aimAngleRad.value = 0f
        _shotPower.value = 0.65f
    }

    private fun resetTable() {
        val initialBalls = PoolPhysicsEngine.createInitialBalls()
        _balls.value = initialBalls
    }

    fun confirmBallInHand() {
        if (_hasBallInHand.value) {
            _hasBallInHand.value = false
            _recentLog.value = "Đã khóa vị trí bi cái. Hãy ngắm và đánh!"
        }
    }

    fun executeShot() {
        if (_isSimulating.value || _isGameOver.value) return
        if (_hasBallInHand.value) {
            _hasBallInHand.value = false
        }

        val cue = _balls.value.find { it.isCueBall } ?: return
        if (cue.isPotted) return

        val shooter = _currentTurn.value
        val shooterPlayer = if (shooter == PlayerId.PLAYER_1) _player1.value else _player2.value
        val shooterGroup = shooterPlayer.group
        val shooterCleared = shooterGroup != null && !_balls.value.any { !it.isPotted && it.group == shooterGroup }

        val context = ShotContext(
            shooter = shooter,
            shooterGroupAtStart = shooterGroup,
            shooterClearedAtStart = shooterCleared,
            groupsOpenAtStart = shooterGroup == null,
            isBreak = _isBreakShot.value
        )
        activeShotContext = context

        // Set cue ball initial impulse
        val speed = _shotPower.value * PoolTableConfig.MAX_SHOT_SPEED
        cue.vx = cos(_aimAngleRad.value) * speed
        cue.vy = sin(_aimAngleRad.value) * speed

        soundManager.playCueHit(_shotPower.value)
        _isSimulating.value = true

        if (_gameMode.value == GameMode.P2P_LAN && p2pManager.isConnected) {
            p2pManager.sendShoot(_aimAngleRad.value, _shotPower.value)
        }

        launchPhysicsLoop()
    }

    private fun launchPhysicsLoop() {
        physicsJob?.cancel()
        physicsJob = viewModelScope.launch(Dispatchers.Default) {
            val frameTimeMs = 16L
            var simulationFrames = 0
            val maxSimulationFrames = 350 // ~5.5 seconds max

            while (isActive) {
                simulationFrames++
                val currentBalls = _balls.value
                PoolPhysicsEngine.stepPhysics(
                    balls = currentBalls,
                    shotCtx = activeShotContext,
                    onEvent = { event, magnitude ->
                        when (event) {
                            ShotEvent.BALL_COLLISION -> soundManager.playBallCollision(magnitude)
                            ShotEvent.CUSHION_COLLISION -> soundManager.playCushionHit(magnitude)
                            ShotEvent.POCKET_DROP -> soundManager.playPocketDrop()
                            else -> {}
                        }
                    }
                )

                _balls.value = currentBalls.map { it.copyBall() }

                val isStillMoving = PoolPhysicsEngine.isAnyBallMoving(currentBalls)
                if (!isStillMoving || simulationFrames >= maxSimulationFrames) {
                    // Bring any residual micro-movements to complete rest
                    for (b in currentBalls) {
                        b.vx = 0f
                        b.vy = 0f
                    }
                    _balls.value = currentBalls.map { it.copyBall() }
                    delay(120)
                    resolveShotEnd()
                    break
                }

                delay(frameTimeMs)
            }
        }
    }

    private fun resolveShotEnd() {
        _isSimulating.value = false
        val context = activeShotContext ?: return
        val currentBalls = _balls.value

        val evaluation = PoolRules.evaluateShot(
            shotCtx = context,
            balls = currentBalls,
            players = mapOf(PlayerId.PLAYER_1 to _player1.value, PlayerId.PLAYER_2 to _player2.value)
        )

        // Update player groups if assigned
        if (evaluation.groupAssignmentP1 != null) {
            _player1.value = _player1.value.copy(group = evaluation.groupAssignmentP1)
        }
        if (evaluation.groupAssignmentP2 != null) {
            _player2.value = _player2.value.copy(group = evaluation.groupAssignmentP2)
        }

        _recentLog.value = evaluation.logMessage
        _isBreakShot.value = false

        // Play outcome sounds
        for (event in evaluation.events) {
            when (event) {
                ShotEvent.FOUL -> soundManager.playFoul()
                ShotEvent.WIN -> soundManager.playWin()
                ShotEvent.LOSE -> soundManager.playLose()
                else -> {}
            }
        }

        if (evaluation.isGameOver) {
            _isGameOver.value = true
            _winner.value = evaluation.winner
            _gameOverReason.value = evaluation.logMessage
            return
        }

        // Handle Ball-In-Hand or next turn
        if (evaluation.ballInHandFor != null) {
            _hasBallInHand.value = true
            _currentTurn.value = evaluation.ballInHandFor

            // Ensure cue ball is back on table if scratched
            val cue = currentBalls.find { it.isCueBall }
            if (cue != null && cue.isPotted) {
                cue.isPotted = false
                cue.x = PoolTableConfig.HEAD_SPOT.x
                cue.y = PoolTableConfig.HEAD_SPOT.y
                cue.vx = 0f
                cue.vy = 0f
                _balls.value = currentBalls.map { it.copyBall() }
            }
        } else {
            _hasBallInHand.value = false
            _currentTurn.value = evaluation.nextTurn
        }

        activeShotContext = null

        // Check if AI turn next
        checkAndTriggerAiTurn()
    }

    fun moveBallInHand(x: Float, y: Float) {
        if (!_hasBallInHand.value) return
        val currentBalls = _balls.value
        val cue = currentBalls.find { it.isCueBall } ?: return

        cue.x = x
        cue.y = y
        cue.vx = 0f
        cue.vy = 0f
        cue.isPotted = false
        _balls.value = currentBalls.map { it.copyBall() }

        if (_gameMode.value == GameMode.P2P_LAN && p2pManager.isConnected) {
            p2pManager.sendBallInHand(x, y)
        }
    }

    private fun checkAndTriggerAiTurn() {
        if (_gameMode.value != GameMode.VS_AI || _currentTurn.value != PlayerId.PLAYER_2 || _isGameOver.value) return

        aiThinkingJob?.cancel()
        aiThinkingJob = viewModelScope.launch(Dispatchers.Default) {
            delay(600)

            val decision = PoolAi.decideShot(
                balls = _balls.value,
                aiGroup = _player2.value.group,
                difficulty = _aiDifficulty.value,
                isBreakShot = _isBreakShot.value,
                hasBallInHand = _hasBallInHand.value
            )

            // If AI has ball in hand, position cue ball first
            if (_hasBallInHand.value && decision.ballInHandPlacement != null) {
                moveBallInHand(decision.ballInHandPlacement.x, decision.ballInHandPlacement.y)
                _hasBallInHand.value = false
                delay(400)
            }

            // Smooth aim towards target
            setAim(decision.angleRad, decision.power)
            delay(500)

            // Execute shot
            executeShot()
        }
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val myName = if (_currentTurn.value == PlayerId.PLAYER_1) _player1.value.name else _player2.value.name
        val msg = ChatMessage(senderName = myName, text = text, isMine = true)
        _chatMessages.value = _chatMessages.value + msg
        postDanmaku(myName, text, isMine = true)

        if (_gameMode.value == GameMode.P2P_LAN && p2pManager.isConnected) {
            p2pManager.sendChat(myName, text)
        } else if (_gameMode.value == GameMode.VS_AI) {
            viewModelScope.launch {
                delay(1200)
                val aiResponses = listOf(
                    "Cú đánh đẹp mắt đấy! 🔥",
                    "Để xem cơ này của tôi thế nào! 😎",
                    "Gần vào lỗ rồi, quá tiếc! 🎱",
                    "Trận đấu hấp dẫn thật! 👏",
                    "Cơ thủ tay nghề cao đấy! 🎯"
                )
                val aiReply = aiResponses.random()
                val aiMsg = ChatMessage(senderName = _player2.value.name, text = aiReply, isMine = false)
                _chatMessages.value = _chatMessages.value + aiMsg
                postDanmaku(_player2.value.name, aiReply, isMine = false)
            }
        }
    }

    private fun postDanmaku(sender: String, text: String, isMine: Boolean) {
        val lane = (lastLane + 1) % 4
        lastLane = lane
        val item = DanmakuItem(
            id = ++danmakuCounter,
            senderName = sender,
            text = text,
            isMine = isMine,
            lane = lane
        )
        _danmakuItems.value = _danmakuItems.value + item
    }

    fun removeDanmaku(id: Long) {
        _danmakuItems.value = _danmakuItems.value.filter { it.id != id }
    }

    fun toggleMic() {
        _isMicEnabled.value = !_isMicEnabled.value
        _recentLog.value = if (_isMicEnabled.value) "🎙️ Đã bật micro (Voice chat)" else "🎙️ Đã tắt micro"
    }

    fun toggleCamera() {
        _isCameraEnabled.value = !_isCameraEnabled.value
        _recentLog.value = if (_isCameraEnabled.value) "📹 Đã bật camera trực tiếp" else "📹 Đã tắt camera"
    }

    fun toggleSound() {
        soundManager.isSoundEnabled = !soundManager.isSoundEnabled
    }

    fun toggleHaptics() {
        soundManager.isHapticsEnabled = !soundManager.isHapticsEnabled
    }

    // P2P Callbacks
    override fun onPeerConnected(peerName: String) {
        _recentLog.value = "Đối thủ $peerName đã kết nối thành công!"
    }

    override fun onPeerDisconnected() {
        _recentLog.value = "Đối thủ đã ngắt kết nối."
    }

    override fun onPeerAimUpdated(angleRad: Float, power: Float) {
        _aimAngleRad.value = angleRad
        _shotPower.value = power
    }

    override fun onPeerShoot(angleRad: Float, power: Float) {
        _aimAngleRad.value = angleRad
        _shotPower.value = power
        executeShot()
    }

    override fun onPeerBallInHandPlace(x: Float, y: Float) {
        moveBallInHand(x, y)
        _hasBallInHand.value = false
    }

    override fun onPeerChat(sender: String, message: String) {
        val msg = ChatMessage(senderName = sender, text = message, isMine = false)
        _chatMessages.value = _chatMessages.value + msg
        postDanmaku(sender, message, isMine = false)
    }

    override fun onPeerRematchRequest() {
        _recentLog.value = "Đối thủ muốn chơi lại một ván mới!"
    }

    override fun onPeerRematchAccepted() {
        startNewMatch()
    }

    override fun onCleared() {
        super.onCleared()
        physicsJob?.cancel()
        aiThinkingJob?.cancel()
        p2pManager.disconnect()
        soundManager.release()
    }
}
