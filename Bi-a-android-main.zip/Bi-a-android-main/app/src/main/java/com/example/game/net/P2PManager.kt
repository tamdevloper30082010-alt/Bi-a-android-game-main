package com.example.game.net

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import kotlin.random.Random

sealed class P2PConnectionState {
    object Idle : P2PConnectionState()
    data class Hosting(val roomCode: String, val localIp: String) : P2PConnectionState()
    data class Connecting(val roomCode: String) : P2PConnectionState()
    data class Connected(val isHost: Boolean, val peerName: String) : P2PConnectionState()
    data class Error(val message: String) : P2PConnectionState()
}

interface P2PMessageListener {
    fun onPeerConnected(peerName: String)
    fun onPeerDisconnected()
    fun onPeerAimUpdated(angleRad: Float, power: Float)
    fun onPeerShoot(angleRad: Float, power: Float)
    fun onPeerBallInHandPlace(x: Float, y: Float)
    fun onPeerChat(sender: String, message: String)
    fun onPeerRematchRequest()
    fun onPeerRematchAccepted()
}

class P2PManager(
    private val scope: CoroutineScope,
    private val listener: P2PMessageListener
) {
    var state: P2PConnectionState = P2PConnectionState.Idle
        private set

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var writer: PrintWriter? = null
    private var reader: BufferedReader? = null
    private var networkJob: Job? = null

    val isConnected: Boolean get() = state is P2PConnectionState.Connected
    val isHost: Boolean get() = (state as? P2PConnectionState.Connected)?.isHost == true

    fun getLocalIpAddress(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addresses = iface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "127.0.0.1"
                    }
                }
            }
        } catch (_: Exception) {}
        return "127.0.0.1"
    }

    fun startHost(playerName: String, onStatusUpdate: (P2PConnectionState) -> Unit) {
        disconnect()
        val roomCode = String.format("%03d", Random.nextInt(100, 999))
        val localIp = getLocalIpAddress()
        state = P2PConnectionState.Hosting(roomCode, localIp)
        onStatusUpdate(state)

        networkJob = scope.launch(Dispatchers.IO) {
            try {
                val server = ServerSocket(8888)
                serverSocket = server
                val socket = server.accept()
                clientSocket = socket
                writer = PrintWriter(socket.getOutputStream(), true)
                reader = BufferedReader(InputStreamReader(socket.getInputStream()))

                // Send Host Hello
                val helloMsg = JSONObject().apply {
                    put("type", "HELLO")
                    put("name", playerName)
                    put("isHost", true)
                }
                writer?.println(helloMsg.toString())

                withContext(Dispatchers.Main) {
                    state = P2PConnectionState.Connected(isHost = true, peerName = "Khách")
                    onStatusUpdate(state)
                }

                listenForIncomingMessages(onStatusUpdate)
            } catch (e: Exception) {
                if (isActive) {
                    withContext(Dispatchers.Main) {
                        state = P2PConnectionState.Error("Không thể tạo phòng: ${e.localizedMessage}")
                        onStatusUpdate(state)
                    }
                }
            }
        }
    }

    fun joinRoom(
        hostAddressOrCode: String,
        playerName: String,
        onStatusUpdate: (P2PConnectionState) -> Unit
    ) {
        disconnect()
        state = P2PConnectionState.Connecting(hostAddressOrCode)
        onStatusUpdate(state)

        networkJob = scope.launch(Dispatchers.IO) {
            try {
                // If it's an IP address, connect directly. If 3 digits, try local subnet or localhost
                val targetIp = if (hostAddressOrCode.contains(".")) {
                    hostAddressOrCode.trim()
                } else {
                    // Try connecting to same subnet gateway or fallback to localhost for testing
                    val localIp = getLocalIpAddress()
                    val prefix = localIp.substringBeforeLast(".")
                    "$prefix.1" // or localhost
                }

                val socket = try {
                    Socket(targetIp, 8888)
                } catch (_: Exception) {
                    Socket("127.0.0.1", 8888)
                }

                clientSocket = socket
                writer = PrintWriter(socket.getOutputStream(), true)
                reader = BufferedReader(InputStreamReader(socket.getInputStream()))

                // Send Guest Hello
                val helloMsg = JSONObject().apply {
                    put("type", "HELLO")
                    put("name", playerName)
                    put("isHost", false)
                }
                writer?.println(helloMsg.toString())

                withContext(Dispatchers.Main) {
                    state = P2PConnectionState.Connected(isHost = false, peerName = "Chủ phòng")
                    onStatusUpdate(state)
                }

                listenForIncomingMessages(onStatusUpdate)
            } catch (e: Exception) {
                if (isActive) {
                    withContext(Dispatchers.Main) {
                        state = P2PConnectionState.Error("Không thể tham gia phòng: ${e.localizedMessage}")
                        onStatusUpdate(state)
                    }
                }
            }
        }
    }

    private suspend fun listenForIncomingMessages(onStatusUpdate: (P2PConnectionState) -> Unit) {
        val br = reader ?: return
        try {
            while (scope.isActive) {
                val line = br.readLine() ?: break
                val json = JSONObject(line)
                withContext(Dispatchers.Main) {
                    handleIncomingJson(json, onStatusUpdate)
                }
            }
        } catch (_: Exception) {
        } finally {
            withContext(Dispatchers.Main) {
                listener.onPeerDisconnected()
                state = P2PConnectionState.Idle
                onStatusUpdate(state)
            }
        }
    }

    private fun handleIncomingJson(json: JSONObject, onStatusUpdate: (P2PConnectionState) -> Unit) {
        when (json.optString("type")) {
            "HELLO" -> {
                val peerName = json.optString("name", "Người chơi")
                val isHostPeer = json.optBoolean("isHost", false)
                state = P2PConnectionState.Connected(isHost = !isHostPeer, peerName = peerName)
                onStatusUpdate(state)
                listener.onPeerConnected(peerName)
            }
            "AIM" -> {
                val angle = json.optDouble("angle", 0.0).toFloat()
                val power = json.optDouble("power", 0.0).toFloat()
                listener.onPeerAimUpdated(angle, power)
            }
            "SHOOT" -> {
                val angle = json.optDouble("angle", 0.0).toFloat()
                val power = json.optDouble("power", 0.0).toFloat()
                listener.onPeerShoot(angle, power)
            }
            "BALL_IN_HAND" -> {
                val x = json.optDouble("x", 0.0).toFloat()
                val y = json.optDouble("y", 0.0).toFloat()
                listener.onPeerBallInHandPlace(x, y)
            }
            "CHAT" -> {
                val sender = json.optString("sender", "Đối thủ")
                val text = json.optString("text", "")
                listener.onPeerChat(sender, text)
            }
            "REMATCH_REQ" -> {
                listener.onPeerRematchRequest()
            }
            "REMATCH_ACCEPT" -> {
                listener.onPeerRematchAccepted()
            }
        }
    }

    fun sendAim(angleRad: Float, power: Float) {
        sendJson(JSONObject().apply {
            put("type", "AIM")
            put("angle", angleRad.toDouble())
            put("power", power.toDouble())
        })
    }

    fun sendShoot(angleRad: Float, power: Float) {
        sendJson(JSONObject().apply {
            put("type", "SHOOT")
            put("angle", angleRad.toDouble())
            put("power", power.toDouble())
        })
    }

    fun sendBallInHand(x: Float, y: Float) {
        sendJson(JSONObject().apply {
            put("type", "BALL_IN_HAND")
            put("x", x.toDouble())
            put("y", y.toDouble())
        })
    }

    fun sendChat(senderName: String, message: String) {
        sendJson(JSONObject().apply {
            put("type", "CHAT")
            put("sender", senderName)
            put("text", message)
        })
    }

    fun sendRematchRequest() {
        sendJson(JSONObject().apply { put("type", "REMATCH_REQ") })
    }

    fun sendRematchAccept() {
        sendJson(JSONObject().apply { put("type", "REMATCH_ACCEPT") })
    }

    private fun sendJson(json: JSONObject) {
        scope.launch(Dispatchers.IO) {
            try {
                writer?.println(json.toString())
            } catch (_: Exception) {}
        }
    }

    fun disconnect() {
        networkJob?.cancel()
        networkJob = null
        try { writer?.close() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { clientSocket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        writer = null
        reader = null
        clientSocket = null
        serverSocket = null
        state = P2PConnectionState.Idle
    }
}
