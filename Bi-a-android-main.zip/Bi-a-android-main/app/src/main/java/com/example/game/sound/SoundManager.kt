package com.example.game.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * High-performance, zero-codec PCM audio clip using direct static AudioTrack buffers.
 * Does not invoke MediaCodec, SoundDecoder, or external decoders, preventing
 * Codec2 component query failures in virtualized or containerized Android environments.
 */
private class PcmAudioClip(
    private val samples: ShortArray,
    private val sampleRate: Int = 22050
) {
    private var audioTrack: AudioTrack? = null

    init {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build().also { track ->
                    track.write(samples, 0, samples.size)
                }
        } catch (_: Exception) {
            audioTrack = null
        }
    }

    fun play(volume: Float = 1.0f, pitchMultiplier: Float = 1.0f) {
        val track = audioTrack ?: return
        try {
            if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                track.stop()
            }
            track.reloadStaticData()
            track.setVolume(volume.coerceIn(0f, 1f))
            if (pitchMultiplier != 1.0f) {
                val targetRate = (sampleRate * pitchMultiplier).toInt().coerceIn(8000, 48000)
                track.setPlaybackRate(targetRate)
            }
            track.play()
        } catch (_: Exception) {}
    }

    fun release() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (_: Exception) {}
    }
}

class SoundManager(private val context: Context) {

    var isSoundEnabled: Boolean = true
    var isHapticsEnabled: Boolean = true

    private val soundScope = CoroutineScope(Dispatchers.Default)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vm?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val sampleRate = 22050

    private var clipCueHit: PcmAudioClip? = null
    private var ballCollisionClips: Array<PcmAudioClip>? = null
    private var ballCollisionIndex = 0
    private var clipCushionHit: PcmAudioClip? = null
    private var clipPocketDrop: PcmAudioClip? = null
    private var clipFoul: PcmAudioClip? = null
    private var clipWin: PcmAudioClip? = null
    private var clipLose: PcmAudioClip? = null
    private var clipClick: PcmAudioClip? = null

    private var lastCollisionTime = 0L
    private var lastCushionTime = 0L
    private var lastVibrationTime = 0L

    init {
        soundScope.launch {
            initSounds()
            cleanupLegacyCacheFiles()
        }
    }

    private fun cleanupLegacyCacheFiles() {
        try {
            context.cacheDir.listFiles { file ->
                file.name.startsWith("snd_") && file.name.endsWith(".wav")
            }?.forEach { it.delete() }
        } catch (_: Exception) {}
    }

    private fun initSounds() {
        try {
            clipCueHit = PcmAudioClip(generateCueHit(), sampleRate)

            val ballSamples = generateBallCollision()
            ballCollisionClips = Array(3) {
                PcmAudioClip(ballSamples, sampleRate)
            }

            clipCushionHit = PcmAudioClip(generateCushionHit(), sampleRate)
            clipPocketDrop = PcmAudioClip(generatePocketDrop(), sampleRate)
            clipFoul = PcmAudioClip(generateFoul(), sampleRate)
            clipWin = PcmAudioClip(generateWin(), sampleRate)
            clipLose = PcmAudioClip(generateLose(), sampleRate)
            clipClick = PcmAudioClip(generateClick(), sampleRate)
        } catch (_: Exception) {
            // Audio init fallback
        }
    }

    private fun generateCueHit(): ShortArray {
        val durMs = 80
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        val baseFreq = 220.0
        val volume = (Short.MAX_VALUE * 0.85f).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 45.0)
            val wave = sin(2.0 * PI * baseFreq * t) * 0.6 + sin(2.0 * PI * (baseFreq * 2.8) * t) * 0.4
            buffer[i] = (wave * decay * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun generateBallCollision(): ShortArray {
        val durMs = 45
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        val freq = 1800.0
        val volume = (Short.MAX_VALUE * 0.75f).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 110.0)
            val wave = sin(2.0 * PI * freq * t) * 0.7 + sin(2.0 * PI * (freq * 1.5) * t) * 0.3
            buffer[i] = (wave * decay * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun generateCushionHit(): ShortArray {
        val durMs = 60
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        val freq = 130.0
        val volume = (Short.MAX_VALUE * 0.6f).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 50.0)
            val wave = sin(2.0 * PI * freq * t)
            buffer[i] = (wave * decay * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun generatePocketDrop(): ShortArray {
        val durMs = 160
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        val volume = (Short.MAX_VALUE * 0.7f).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val freq = if (t < 0.08) 580.0 else 380.0
            val decay = exp(-t * 24.0)
            val wave = sin(2.0 * PI * freq * t)
            buffer[i] = (wave * decay * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun generateFoul(): ShortArray {
        val durMs = 260
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        val volume = (Short.MAX_VALUE * 0.55f).toInt()
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val sinVal = sin(2.0 * PI * 140.0 * t)
            val square = if (sinVal > 0) 1.0 else -1.0
            val decay = exp(-t * 8.0)
            buffer[i] = (square * decay * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    private fun generateWin(): ShortArray {
        val notes = listOf(523.25, 659.25, 783.99, 1046.50)
        val noteDurMs = 110
        val totalSamples = (sampleRate * (noteDurMs * notes.size / 1000.0)).toInt()
        val buffer = ShortArray(totalSamples)
        val noteSamples = (sampleRate * (noteDurMs / 1000.0)).toInt()

        for (n in notes.indices) {
            val freq = notes[n]
            val offset = n * noteSamples
            for (i in 0 until noteSamples) {
                val idx = offset + i
                if (idx >= totalSamples) break
                val t = i.toDouble() / sampleRate
                val decay = exp(-t * 12.0)
                val wave = sin(2.0 * PI * freq * t)
                buffer[idx] = (wave * decay * (Short.MAX_VALUE * 0.65f)).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }
        return buffer
    }

    private fun generateLose(): ShortArray {
        val notes = listOf(392.0, 311.13, 261.63)
        val noteDurMs = 150
        val totalSamples = (sampleRate * (noteDurMs * notes.size / 1000.0)).toInt()
        val buffer = ShortArray(totalSamples)
        val noteSamples = (sampleRate * (noteDurMs / 1000.0)).toInt()

        for (n in notes.indices) {
            val freq = notes[n]
            val offset = n * noteSamples
            for (i in 0 until noteSamples) {
                val idx = offset + i
                if (idx >= totalSamples) break
                val t = i.toDouble() / sampleRate
                val decay = exp(-t * 10.0)
                val wave = sin(2.0 * PI * freq * t)
                buffer[idx] = (wave * decay * (Short.MAX_VALUE * 0.55f)).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }
        return buffer
    }

    private fun generateClick(): ShortArray {
        val durMs = 25
        val numSamples = (sampleRate * (durMs / 1000.0)).toInt()
        val buffer = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 180.0)
            val wave = sin(2.0 * PI * 1800.0 * t)
            buffer[i] = (wave * decay * (Short.MAX_VALUE * 0.4f)).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return buffer
    }

    fun playCueHit(power: Float) {
        if (!isSoundEnabled) return
        val vol = power.coerceIn(0.2f, 1f)
        clipCueHit?.play(vol, 1.0f)
        triggerVibration(30, (power * 255).toInt().coerceIn(40, 255))
    }

    fun playBallCollision(power: Float) {
        if (!isSoundEnabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastCollisionTime < 40) return // Throttle to prevent audio overload
        lastCollisionTime = now

        val vol = power.coerceIn(0.15f, 1f)
        val rate = (0.95f + power * 0.15f).coerceIn(0.8f, 1.3f)
        val clips = ballCollisionClips
        if (!clips.isNullOrEmpty()) {
            val clip = clips[ballCollisionIndex % clips.size]
            ballCollisionIndex++
            clip.play(vol, rate)
        }
        triggerVibration(15, (power * 160).toInt().coerceIn(25, 180))
    }

    fun playCushionHit(power: Float) {
        if (!isSoundEnabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastCushionTime < 60) return
        lastCushionTime = now

        val vol = (power * 0.6f).coerceIn(0.1f, 0.8f)
        clipCushionHit?.play(vol, 1.0f)
    }

    fun playPocketDrop() {
        if (!isSoundEnabled) return
        clipPocketDrop?.play(0.9f, 1.0f)
        triggerVibration(40, 180)
    }

    fun playFoul() {
        if (!isSoundEnabled) return
        clipFoul?.play(0.8f, 1.0f)
        triggerVibration(120, 240)
    }

    fun playWin() {
        if (!isSoundEnabled) return
        clipWin?.play(0.9f, 1.0f)
        triggerVibration(200, 200)
    }

    fun playLose() {
        if (!isSoundEnabled) return
        clipLose?.play(0.8f, 1.0f)
    }

    fun playClick() {
        if (!isSoundEnabled) return
        clipClick?.play(0.5f, 1.0f)
    }

    private fun triggerVibration(durationMs: Long, amplitude: Int = 128) {
        if (!isHapticsEnabled || vibrator == null || !vibrator.hasVibrator()) return
        val now = SystemClock.uptimeMillis()
        if (now - lastVibrationTime < 70) return
        lastVibrationTime = now

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(durationMs, amplitude.coerceIn(1, 255))
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        try {
            clipCueHit?.release()
            ballCollisionClips?.forEach { it.release() }
            clipCushionHit?.release()
            clipPocketDrop?.release()
            clipFoul?.release()
            clipWin?.release()
            clipLose?.release()
            clipClick?.release()
        } catch (_: Exception) {}
    }
}
