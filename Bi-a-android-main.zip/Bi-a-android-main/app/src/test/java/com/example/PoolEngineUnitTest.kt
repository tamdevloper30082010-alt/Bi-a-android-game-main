package com.example

import com.example.game.ai.PoolAi
import com.example.game.model.AiDifficulty
import com.example.game.model.BallGroup
import com.example.game.model.PlayerId
import com.example.game.model.PlayerInfo
import com.example.game.model.PoolTableConfig
import com.example.game.model.ShotContext
import com.example.game.model.ShotEvent
import com.example.game.physics.PoolPhysicsEngine
import com.example.game.rules.PoolRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PoolEngineUnitTest {

    @Test
    fun testInitialRackSetup() {
        val balls = PoolPhysicsEngine.createInitialBalls()
        assertEquals(16, balls.size)

        val cue = balls.find { it.isCueBall }
        assertNotNull(cue)
        assertEquals(0, cue?.num)
        assertEquals(PoolTableConfig.HEAD_SPOT.x, cue!!.x, 0.01f)
        assertEquals(PoolTableConfig.HEAD_SPOT.y, cue.y, 0.01f)

        val eightBall = balls.find { it.isEightBall }
        assertNotNull(eightBall)
        assertEquals(8, eightBall?.num)

        val solids = balls.filter { it.group == BallGroup.SOLID }
        assertEquals(7, solids.size)

        val stripes = balls.filter { it.group == BallGroup.STRIPE }
        assertEquals(7, stripes.size)
    }

    @Test
    fun testCuePlacementValidity() {
        val balls = PoolPhysicsEngine.createInitialBalls()

        // Valid inside table bounds and away from other balls
        assertTrue(PoolPhysicsEngine.isValidCuePlacement(300f, 250f, balls, false))

        // Invalid outside table bounds
        assertFalse(PoolPhysicsEngine.isValidCuePlacement(10f, 10f, balls, false))

        // Invalid overlapping foot spot where balls are racked
        assertFalse(PoolPhysicsEngine.isValidCuePlacement(PoolTableConfig.FOOT_SPOT.x, PoolTableConfig.FOOT_SPOT.y, balls, false))
    }

    @Test
    fun testPhysicsSimulationMovementAndFriction() {
        val balls = PoolPhysicsEngine.createInitialBalls()
        val cue = balls.first { it.isCueBall }
        cue.vx = 200f
        cue.vy = 0f

        assertTrue(PoolPhysicsEngine.isAnyBallMoving(balls))

        val ctx = ShotContext(
            shooter = PlayerId.PLAYER_1,
            shooterGroupAtStart = null,
            shooterClearedAtStart = false,
            groupsOpenAtStart = true,
            isBreak = true
        )

        // Step physics multiple times
        for (i in 0 until 60) {
            PoolPhysicsEngine.stepPhysics(balls, ctx)
        }

        // Cue ball should have moved to the right
        assertTrue(cue.x > PoolTableConfig.HEAD_SPOT.x)
        // Velocity should have decayed due to friction
        assertTrue(cue.vx < 200f)
    }

    @Test
    fun testScratchFoulEvaluation() {
        val balls = PoolPhysicsEngine.createInitialBalls()
        val cue = balls.first { it.isCueBall }
        cue.isPotted = true

        val ctx = ShotContext(
            shooter = PlayerId.PLAYER_1,
            shooterGroupAtStart = BallGroup.SOLID,
            shooterClearedAtStart = false,
            groupsOpenAtStart = false,
            isBreak = false,
            scratch = true,
            firstContactBallNum = 1
        )

        val players = mapOf(
            PlayerId.PLAYER_1 to PlayerInfo(PlayerId.PLAYER_1, "P1", group = BallGroup.SOLID),
            PlayerId.PLAYER_2 to PlayerInfo(PlayerId.PLAYER_2, "P2", group = BallGroup.STRIPE)
        )

        val result = PoolRules.evaluateShot(ctx, balls, players)
        assertTrue(result.isFoul)
        assertTrue(result.events.contains(ShotEvent.FOUL))
        assertEquals(PlayerId.PLAYER_2, result.ballInHandFor)
    }

    @Test
    fun testAiShotDecisionGeneratesValidValues() {
        val balls = PoolPhysicsEngine.createInitialBalls()
        val decision = PoolAi.decideShot(
            balls = balls,
            aiGroup = BallGroup.SOLID,
            difficulty = AiDifficulty.HARD,
            isBreakShot = false,
            hasBallInHand = false
        )

        assertTrue(decision.power in 0.1f..1.0f)
        assertFalse(decision.angleRad.isNaN())
    }
}
